export interface DepartmentInfo {
  id: string;
  name: string;
  nameHi: string;
  nodalOfficer: string;
  phone: string;
  email: string;
  categories: string[];
}

export interface EmergencyContact {
  service: string;
  serviceHi: string;
  number: string;
  available: string;
  iconName: string;
  isTollFree?: boolean;
}

export const JHABUA_TEHSILS = [
  { id: 'jhabua', name: 'Jhabua', nameHi: 'झाबुआ' },
  { id: 'petlawad', name: 'Petlawad', nameHi: 'पेटलावद' },
  { id: 'thandla', name: 'Thandla', nameHi: 'थांदला' },
  { id: 'meghnagar', name: 'Meghnagar', nameHi: 'मेघनगर' },
  { id: 'ranapur', name: 'Ranapur', nameHi: 'राणापुर' },
  { id: 'rama', name: 'Rama', nameHi: 'रामा' },
];

export const COMPLAINT_CATEGORIES = [
  { id: 'road', name: 'Road & PWD / सड़क एवं निर्माण', nameEn: 'Road & Infrastructure', nameHi: 'सड़क एवं पुलिया निर्माण', dept: 'PWD / Pradhan Mantri Gram Sadak' },
  { id: 'water', name: 'Water & Handpump / नल-जल एवं हैंडपंप', nameEn: 'Drinking Water & Handpumps', nameHi: 'पेयजल एवं हैंडपंप सुधार', dept: 'PHE (लोक स्वास्थ्य यांत्रिकी)' },
  { id: 'electricity', name: 'Electricity / विद्युत आपूर्ति एवं ट्रांसफार्मर', nameEn: 'Electricity & Transformer', nameHi: 'विद्युत एवं ट्रांसफार्मर', dept: 'MPPKVVCL (विद्युत वितरण कंपनी)' },
  { id: 'health', name: 'Health & Hospital / स्वास्थ्य एवं चिकित्सा', nameEn: 'Health & Hospital Services', nameHi: 'स्वास्थ्य एवं चिकित्सा सेवाएं', dept: 'CMHO (मुख्य चिकित्सा अधिकारी)' },
  { id: 'education', name: 'Education & School / शिक्षा एवं विद्यालय', nameEn: 'Education & Mid-day Meal', nameHi: 'शिक्षा एवं मध्यान्ह भोजन', dept: 'District Education Office (DEO)' },
  { id: 'sanitation', name: 'Sanitation & Garbage / स्वच्छता एवं कचरा', nameEn: 'Sanitation & Drainage', nameHi: 'स्वच्छता एवं नाली सफाई', dept: 'Nagar Palika / Janpad Panchayat' },
  { id: 'revenue', name: 'Revenue & Land / राजस्व, नामांतरण व सीमांकन', nameEn: 'Revenue, Patwari & Land Records', nameHi: 'राजस्व, नामांतरण एवं सीमांकन', dept: 'SDM / Tehsildar Office' },
  { id: 'ration', name: 'Ration & PDS / उचित मूल्य दुकान एवं राशन', nameEn: 'Ration & Food Supplies', nameHi: 'राशन एवं नागरिक आपूर्ति', dept: 'Food & Civil Supplies' },
  { id: 'food_safety', name: 'Food Safety & Adulteration / खाद्य सुरक्षा एवं मिलावट', nameEn: 'Food Safety & Quality', nameHi: 'खाद्य सुरक्षा एवं गुणवत्ता', dept: 'Food Safety Administration' },
  { id: 'panchayat', name: 'Panchayat & Rural Dev / ग्राम पंचायत विकास', nameEn: 'Panchayat & MNREGA', nameHi: 'पंचायत एवं मनरेगा कार्य', dept: 'Zila Panchayat (सीईओ जिला पंचायत)' },
  { id: 'agriculture', name: 'Agriculture & Farmer Welfare / कृषि एवं किसान कल्याण', nameEn: 'Agriculture & Kisan Kalyan', nameHi: 'कृषि एवं किसान कल्याण', dept: 'Deputy Director Agriculture (DDA)' },
  { id: 'other', name: 'Other Grievance / अन्य समस्या', nameEn: 'Other Administrative Matter', nameHi: 'अन्य प्रशासनिक विषय', dept: 'Collectorate Public Grievance Cell' },
];

export const EMERGENCY_HELPLINES: EmergencyContact[] = [
  { service: 'CM Helpline', serviceHi: 'मुख्यमंत्री हेल्पलाइन', number: '181', available: '24x7 Toll-Free', iconName: 'PhoneCall', isTollFree: true },
  { service: 'Kisan Call Center', serviceHi: 'किसान कॉल सेंटर (कृषि सलाह)', number: '1800-180-1551', available: '6 AM - 10 PM Toll-Free', iconName: 'Tractor', isTollFree: true },
  { service: 'Collectorate Control Room', serviceHi: 'कलेक्टर कार्यालय नियंत्रण कक्ष', number: '07392-243303', available: '10 AM - 6 PM', iconName: 'Landline' },
  { service: 'Police Emergency', serviceHi: 'पुलिस आपातकालीन सेवा', number: '100 / 112', available: '24x7', iconName: 'ShieldAlert', isTollFree: true },
  { service: 'Ambulance Service', serviceHi: 'एम्बुलेंस (संजीवनी)', number: '108', available: '24x7 Free', iconName: 'Activity', isTollFree: true },
  { service: 'Women Helpline', serviceHi: 'महिला हेल्पलाइन', number: '1091', available: '24x7 Free', iconName: 'HeartHandshake', isTollFree: true },
  { service: 'Electricity Breakdown Help', serviceHi: 'विद्युत शिकायत केंद्र (झाबुआ)', number: '1912', available: '24x7 Free', iconName: 'Zap', isTollFree: true },
  { service: 'Child Helpline', serviceHi: 'बाल संरक्षण हेल्पलाइन', number: '1098', available: '24x7 Free', iconName: 'Smile', isTollFree: true },
  { service: 'Disaster Relief / Flood', serviceHi: 'आपदा प्रबंधन झाबुआ', number: '07392-244321', available: '24x7 During Emergencies', iconName: 'AlertTriangle' },
];

export const KEY_OFFICIALS = [
  {
    designation: 'Collector & District Magistrate',
    designationHi: 'कलेक्टर एवं जिला दंडाधिकारी',
    office: 'Collectorate Jhabua (M.P.)',
    phone: '07392-243202',
    email: 'dmjhabua@mp.gov.in',
    address: 'Collector Office, Rajgarh Road, Jhabua (M.P.) - 457661',
  },
  {
    designation: 'Superintendent of Police (SP)',
    designationHi: 'पुलिस अधीक्षक (SP)',
    office: 'Police Headquarters Jhabua',
    phone: '07392-244300',
    email: 'sp_jhabua@mppolice.gov.in',
    address: 'SP Office Complex, Court Road, Jhabua',
  },
  {
    designation: 'Chief Executive Officer (Zila Panchayat)',
    designationHi: 'मुख्य कार्यपालन अधिकारी (जिला पंचायत)',
    office: 'Zila Panchayat Jhabua',
    phone: '07392-243355',
    email: 'ceozp-jhb@mp.gov.in',
    address: 'Zila Panchayat Bhavan, Jhabua',
  },
  {
    designation: 'Sub-Divisional Magistrate (SDM Jhabua)',
    designationHi: 'अनुविभागीय अधिकारी (एस.डी.एम. झाबुआ)',
    office: 'SDM Office, Tehsil Compound Jhabua',
    phone: '07392-243405',
    email: 'sdmjhabua@mp.gov.in',
    address: 'Tehsil Complex, Jhabua',
  },
  {
    designation: 'Executive Engineer (PHE - Water)',
    designationHi: 'कार्यपालन यंत्री (लोक स्वास्थ्य यांत्रिकी - जल)',
    office: 'PHE Division Jhabua',
    phone: '07392-243512',
    email: 'ee-phe-jhb@mp.gov.in',
    address: 'PHE Division Office, Jhabua',
  },
  {
    designation: 'Executive Engineer (MPPKVVCL - Electricity)',
    designationHi: 'कार्यपालन यंत्री (म.प्र. पश्चिम क्षेत्र विद्युत)',
    office: 'Electricity Board Jhabua',
    phone: '07392-243280',
    email: 'ee_jhabua@mpwz.co.in',
    address: 'Power House Colony, Jhabua',
  },
  {
    designation: 'Deputy Director Agriculture (DDA)',
    designationHi: 'उप संचालक कृषि',
    office: 'Agriculture Department Jhabua',
    phone: '07392-243380',
    email: 'dda_jhabua@mp.gov.in',
    address: 'Krishi Upaj Mandi Campus, Jhabua',
  },
  {
    designation: 'Veterinary Officer / Animal Husbandry',
    designationHi: 'पशु चिकित्सा अधिकारी',
    office: 'Animal Husbandry Dept Jhabua',
    phone: '07392-244101',
    email: 'vet_jhabua@mp.gov.in',
    address: 'Veterinary Hospital Campus, Jhabua',
  }
];
