import { Complaint } from '../types';

export const INITIAL_COMPLAINTS: Complaint[] = [
  {
    id: 'jhb-1001',
    complaintNumber: 'JHB-2026-8941',
    name: 'रमेश सिंगार (Ramesh Singar)',
    mobile: '9826145678',
    email: 'ramesh.singar@gmail.com',
    tehsil: 'Petlawad',
    village: 'करवड़ (Karwad)',
    address: 'वार्ड नंबर 4, मुख्य बाजार के पास, करवड़',
    category: 'Water & Handpump / नल-जल एवं हैंडपंप',
    priority: 'Urgent',
    description: 'गांव के प्राथमिक विद्यालय के सामने लगा सार्वजनिक हैंडपंप पिछले 15 दिनों से खराब है। पूरे मोहल्ले में पीने के पानी की गंभीर किल्लत है। कृपया शीघ्र सुधार करवाएं।',
    status: 'In Progress',
    createdAt: '2026-08-10 10:30 AM',
    assignedDepartment: 'PHE (लोक स्वास्थ्य यांत्रिकी विभाग)',
    assignedOfficer: 'श्री के. सी. वर्मा (सहायक यंत्री, पीएचई पेटलावद)',
    officerRemark: 'हैंडपंप मैकेनिक दल को स्थल निरीक्षण हेतु निर्देशित किया गया है। नई पाइप व वॉशर रिप्लेसमेंट का कार्य जारी है।',
    timeline: [
      {
        title: 'Complaint Registered',
        titleHi: 'शिकायत सफलतापूर्वक दर्ज',
        timestamp: '2026-08-10 10:30 AM',
        description: 'Citizen filed online grievance through Collector Helpline Portal.',
        descriptionHi: 'नागरिक द्वारा झाबुआ कलेक्टर हेल्पलाइन पोर्टल पर शिकायत दर्ज की गई।',
        status: 'Pending'
      },
      {
        title: 'Forwarded to PHE Department',
        titleHi: 'पीएचई विभाग को प्रेषित',
        timestamp: '2026-08-10 02:15 PM',
        description: 'Forwarded to Executive Engineer, PHE Division Jhabua for immediate action.',
        descriptionHi: 'कलेक्टर कार्यालय जनसुनवाई प्रकोष्ठ द्वारा कार्यपालन यंत्री पीएचई को त्वरित निराकरण हेतु अग्रेषित।',
        status: 'Under Review'
      },
      {
        title: 'Field Team Assigned',
        titleHi: 'मैदानी दल रवाना एवं कार्य प्रगति पर',
        timestamp: '2026-08-11 11:00 AM',
        description: 'Technical repair unit dispatched to Karwad village.',
        descriptionHi: 'पेटलावद उपसंभाग के तकनीकी दल द्वारा हैंडपंप सुधार कार्य प्रारंभ कर दिया गया है।',
        status: 'In Progress'
      }
    ]
  },
  {
    id: 'jhb-1002',
    complaintNumber: 'JHB-2026-8812',
    name: 'कमलेश भूरिया (Kamlesh Bhuriya)',
    mobile: '9425098765',
    email: 'k.bhuriya@outlook.com',
    tehsil: 'Ranapur',
    village: 'कुंदनपुर (Kundanpur)',
    address: 'ग्राम कुंदनपुर, पटेल फलिया',
    category: 'Electricity / विद्युत आपूर्ति एवं ट्रांसफार्मर',
    priority: 'Urgent',
    description: 'पटेल फलिया में 63 KVA का ट्रांसफार्मर आंधी-तूफान के कारण 3 दिन पहले जल गया था। 45 घरों और कृषि पंपों में बिजली नहीं है।',
    status: 'Resolved',
    createdAt: '2026-08-08 09:15 AM',
    resolvedAt: '2026-08-10 04:00 PM',
    assignedDepartment: 'MPPKVVCL (पश्चिम क्षेत्र विद्युत वितरण कंपनी)',
    assignedOfficer: 'श्री आर. एस. चौहान (कनिष्ठ यंत्री, राणापुर)',
    officerRemark: 'नया 63 KVA ट्रांसफार्मर स्थापित कर विद्युत आपूर्ति बहाल कर दी गई है। पंचनामा संलग्न है।',
    timeline: [
      {
        title: 'Complaint Registered',
        titleHi: 'शिकायत दर्ज हुई',
        timestamp: '2026-08-08 09:15 AM',
        description: 'Urgent priority marked for burnt transformer.',
        descriptionHi: 'जल चुके ट्रांसफार्मर हेतु प्राथमिकता श्रेणी में शिकायत दर्ज।',
        status: 'Pending'
      },
      {
        title: 'Under Review & Transferred',
        titleHi: 'विद्युत कंपनी को प्रेषित',
        timestamp: '2026-08-08 11:30 AM',
        description: 'Requisition made to regional store for transformer unit.',
        descriptionHi: 'क्षेत्रीय भंडार झाबुआ से नवीन ट्रांसफार्मर आवंटन स्वीकृति प्राप्त हुई।',
        status: 'In Progress'
      },
      {
        title: 'Grievance Resolved',
        titleHi: 'शिकायत का सफल निराकरण',
        timestamp: '2026-08-10 04:00 PM',
        description: 'New transformer charged and electricity restored to all 45 households.',
        descriptionHi: 'नवीन ट्रांसफार्मर चार्ज कर विद्युत आपूर्ति सुचारू कर दी गई है।',
        status: 'Resolved'
      }
    ]
  },
  {
    id: 'jhb-1003',
    complaintNumber: 'JHB-2026-8745',
    name: 'सुनीता डामोर (Sunita Damor)',
    mobile: '9754321098',
    email: '',
    tehsil: 'Thandla',
    village: 'खजुरी (Khajuri)',
    address: 'आंगनवाड़ी केंद्र क्रमांक 2 के पास, खजुरी',
    category: 'Health & Hospital / स्वास्थ्य एवं चिकित्सा',
    priority: 'Normal',
    description: 'उप-स्वास्थ्य केंद्र पर एएनएम दीदी सप्ताह में केवल 1 दिन आती हैं, जिससे गर्भवती महिलाओं व बच्चों के नियमित टीकाकरण में परेशानी हो रही है।',
    status: 'In Progress',
    createdAt: '2026-08-11 03:45 PM',
    assignedDepartment: 'CMHO (स्वास्थ्य विभाग झाबुआ)',
    assignedOfficer: 'डॉ. बी. एल. खराड़ी (बीएमओ थांदला)',
    officerRemark: 'बीएमओ थांदला द्वारा संबंधित एएनएम को कारण बताओ नोटिस जारी किया गया है एवं नियमित उपस्थिति रोस्टर सुनिश्चित किया गया है।',
    timeline: [
      {
        title: 'Complaint Registered',
        titleHi: 'शिकायत दर्ज हुई',
        timestamp: '2026-08-11 03:45 PM',
        description: 'Grievance recorded regarding ANM attendance in sub-health center.',
        descriptionHi: 'उप-स्वास्थ्य केंद्र में स्टाफ की अनुपस्थिति संबंध में शिकायत दर्ज।',
        status: 'Pending'
      },
      {
        title: 'Notice Issued to Officer',
        titleHi: 'जांच अधिकारी नियुक्त व नोटिस जारी',
        timestamp: '2026-08-12 10:00 AM',
        description: 'BMO Thandla directed to conduct surprise inspection.',
        descriptionHi: 'बीएमओ थांदला को औचक निरीक्षण एवं 3 दिवस में प्रतिवेदन प्रस्तुत करने के निर्देश।',
        status: 'In Progress'
      }
    ]
  },
  {
    id: 'jhb-1004',
    complaintNumber: 'JHB-2026-8620',
    name: 'दिलीप मेड़ा (Dilip Meda)',
    mobile: '9179876543',
    email: 'dilip.meda@yahoo.com',
    tehsil: 'Meghnagar',
    village: 'झाड़ोल (Jhadol)',
    address: 'मेघनगर-झाड़ोल पहुंच मार्ग',
    category: 'Road & PWD / सड़क एवं निर्माण',
    priority: 'Normal',
    description: 'मेघनगर से झाड़ोल मुख्य सड़क पर बड़े-बड़े गड्ढे हो गए हैं, बारिश में पानी भरने से दोपहिया वाहन चालकों के गिरने का खतरा रहता है।',
    status: 'Under Review',
    createdAt: '2026-08-12 01:20 PM',
    assignedDepartment: 'MPRDC / PWD Jhabua',
    assignedOfficer: 'श्री एस. के. तिवारी (सहायक यंत्री)',
    officerRemark: 'सड़क पेचवर्क हेतु प्राक्कलन तैयार किया जा रहा है। वर्षा उपरांत तत्काल डामरीकरण प्रस्तावित है।',
    timeline: [
      {
        title: 'Complaint Registered',
        titleHi: 'शिकायत दर्ज हुई',
        timestamp: '2026-08-12 01:20 PM',
        description: 'Road repair grievance recorded.',
        descriptionHi: 'सड़क मरम्मत व गड्ढा मुक्ति हेतु शिकायत पंजीकृत।',
        status: 'Pending'
      },
      {
        title: 'Assigned to PWD Division',
        titleHi: 'लोक निर्माण विभाग को सौंपा गया',
        timestamp: '2026-08-12 04:00 PM',
        description: 'Forwarded to PWD sub-division Meghnagar for survey.',
        descriptionHi: 'सर्वे एवं प्राक्कलन हेतु उपसंभाग मेघनगर को अग्रेषित।',
        status: 'Under Review'
      }
    ]
  }
];
