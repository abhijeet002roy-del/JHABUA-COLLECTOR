import React from 'react';
import { BarChart3, CheckCircle2, Clock, Activity, Zap, TrendingUp, MapPin, Building2, Award, ShieldAlert, Users, Layers, Shield, User } from 'lucide-react';
import { Complaint, Language } from '../types';
import { JHABUA_TEHSILS, COMPLAINT_CATEGORIES } from '../data/districtInfo';
import { translations } from '../translations';

interface PublicStatsProps {
  complaints: Complaint[];
  lang: Language;
  isAdmin?: boolean;
}

export const PublicStats: React.FC<PublicStatsProps> = ({ complaints, lang, isAdmin }) => {
  const t = translations[lang];

  const total = complaints.length;
  const resolved = complaints.filter((c) => c.status === 'Resolved').length;
  const inProgress = complaints.filter((c) => c.status === 'In Progress' || c.status === 'Under Review').length;
  const pending = complaints.filter((c) => c.status === 'Pending').length;

  const resolutionRate = total > 0 ? Math.round((resolved / total) * 100) : 100;

  // Category breakdown
  const categoryCounts = COMPLAINT_CATEGORIES.map((cat) => {
    const count = complaints.filter((c) => c.category.includes(cat.name.split('/')[0].trim())).length;
    const catResolved = complaints.filter(
      (c) => c.category.includes(cat.name.split('/')[0].trim()) && c.status === 'Resolved'
    ).length;
    return {
      name: lang === 'hi' ? cat.nameHi : cat.nameEn,
      total: count,
      resolved: catResolved,
      pct: count > 0 ? Math.round((catResolved / count) * 100) : 100,
    };
  });

  // Tehsil breakdown
  const tehsilCounts = JHABUA_TEHSILS.map((th) => {
    const count = complaints.filter((c) => c.tehsil.toLowerCase() === th.name.toLowerCase()).length;
    const resolvedCount = complaints.filter(
      (c) => c.tehsil.toLowerCase() === th.name.toLowerCase() && c.status === 'Resolved'
    ).length;
    return {
      name: lang === 'hi' ? th.nameHi : th.name,
      count,
      resolvedCount,
      rate: count > 0 ? Math.round((resolvedCount / count) * 100) : 100,
    };
  });

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6 sm:space-y-8">
      {/* Header Dashboard Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200/90">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-[#0f2d4e]/10 text-[#0f2d4e] flex items-center justify-center shrink-0 shadow-2xs">
              {isAdmin ? <BarChart3 className="w-6 h-6" /> : <User className="w-6 h-6" />}
            </div>
            <div>
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-md inline-block mb-1 border border-emerald-200">
                {isAdmin ? (lang === 'hi' ? 'दैनिक अद्यतन पोर्टल' : 'Daily Updated Portal') : (lang === 'hi' ? 'मेरा डैशबोर्ड' : 'My Dashboard')}
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-[#0a2540]">
                {isAdmin 
                  ? (lang === 'hi' ? 'कलेक्टर जनसुनवाई निवारण डैशबोर्ड' : 'Public Grievance Redressal Analytics')
                  : (lang === 'hi' ? 'मेरी शिकायतें (My Grievances)' : 'My Grievances Analytics')
                }
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                {isAdmin
                  ? (lang === 'hi' ? 'झाबुआ जिला प्रशासन द्वारा पारदर्शी व समय-सीमा आधारित शिकायत निवारण रिपोर्ट' : 'Real-time performance metrics and department-wise grievance redressal status for Jhabua district.')
                  : (lang === 'hi' ? 'आपके द्वारा प्रस्तुत शिकायतों की वर्तमान स्थिति एवं प्रगति रिपोर्ट' : 'Real-time status and progress report of the grievances submitted by you.')
                }
              </p>
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3 flex items-center gap-3 shrink-0 self-start sm:self-auto shadow-2xs">
            <Award className="w-6 h-6 text-amber-500" />
            <div>
              <div className="text-[10px] uppercase font-bold text-slate-500">{lang === 'hi' ? 'समाधान दर' : 'Overall SLA Rate'}</div>
              <div className="text-lg font-black text-[#0f2d4e] font-mono">{resolutionRate}% Resolved</div>
            </div>
          </div>
        </div>

        {/* 4 Metric Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mt-6">
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 sm:p-5 transition hover:border-slate-300 shadow-2xs">
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wide">{t.statsTotal}</div>
            <div className="text-2xl sm:text-3xl font-black text-slate-900 mt-1 font-mono">
              {total}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 font-medium">
              {lang === 'hi' ? 'कुल पंजीकृत मामले' : 'All registered cases'}
            </div>
          </div>

          <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-2xl p-4 sm:p-5 transition hover:border-emerald-300 shadow-2xs">
            <div className="text-xs font-bold text-emerald-800 uppercase tracking-wide flex items-center justify-between">
              <span>{t.statsResolved}</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-emerald-700 mt-1 font-mono">
              {resolved}
            </div>
            <div className="text-[11px] text-emerald-700 mt-1 font-medium">
              {resolutionRate}% {lang === 'hi' ? 'निस्तारण पूर्ण' : 'Resolved'}
            </div>
          </div>

          <div className="bg-sky-50/70 border border-sky-200/80 rounded-2xl p-4 sm:p-5 transition hover:border-sky-300 shadow-2xs">
            <div className="text-xs font-bold text-sky-800 uppercase tracking-wide flex items-center justify-between">
              <span>{t.statsInProgress}</span>
              <Clock className="w-4 h-4 text-sky-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-sky-700 mt-1 font-mono">
              {inProgress}
            </div>
            <div className="text-[11px] text-sky-700 mt-1 font-medium">
              {lang === 'hi' ? 'जांच व कार्यवाही जारी' : 'Action under progress'}
            </div>
          </div>

          <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-4 sm:p-5 transition hover:border-amber-300 shadow-2xs">
            <div className="text-xs font-bold text-amber-800 uppercase tracking-wide flex items-center justify-between">
              <span>{t.statsPending}</span>
              <Activity className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-amber-700 mt-1 font-mono">
              {pending}
            </div>
            <div className="text-[11px] text-amber-700 mt-1 font-medium">
              {lang === 'hi' ? 'प्राथमिक समीक्षाधीन' : 'Pending initial review'}
            </div>
          </div>
        </div>
      </div>

      {/* Tehsil-wise Breakdown Matrix */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200/90">
        <h3 className="text-base sm:text-lg font-black text-[#0a2540] mb-1 flex items-center gap-2">
          <MapPin className="w-5 h-5 text-[#0f2d4e]" />
          <span>{lang === 'hi' ? 'तहसील-वार निराकरण प्रगति (Tehsil Redressal Matrix)' : 'Tehsil Redressal Performance'}</span>
        </h3>
        <p className="text-xs text-slate-500 mb-6">
          {lang === 'hi'
            ? 'झाबुआ जिले की सभी 6 तहसीलों में प्राप्त व निराकृत प्रकरणों का विश्लेषण'
            : 'Performance metrics across all 6 administrative tehsils of Jhabua district.'}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {tehsilCounts.map((th, i) => (
            <div key={i} className="bg-slate-50 border border-slate-200/90 rounded-2xl p-4 transition hover:shadow-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-slate-900">{th.name}</span>
                <span className="text-xs font-bold font-mono text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                  {th.rate}%
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-500 mt-2 font-mono">
                <span>{lang === 'hi' ? 'निराकृत:' : 'Resolved:'} <strong className="text-emerald-700">{th.resolvedCount}</strong></span>
                <span>{lang === 'hi' ? 'कुल:' : 'Total:'} <strong className="text-slate-800">{th.count}</strong></span>
              </div>
              <div className="w-full bg-slate-200 h-2 rounded-full mt-2.5 overflow-hidden">
                <div
                  className="bg-[#0a664c] h-full rounded-full transition-all duration-500"
                  style={{ width: `${th.rate}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Department & Category Breakdown */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200/90">
        <h3 className="text-base sm:text-lg font-black text-[#0a2540] mb-1 flex items-center gap-2">
          <Building2 className="w-5 h-5 text-[#0f2d4e]" />
          <span>{lang === 'hi' ? 'विभागीय समस्या वर्गीकरण (Category-wise Redressal)' : 'Department-wise Resolution'}</span>
        </h3>
        <p className="text-xs text-slate-500 mb-6">
          {lang === 'hi'
            ? 'विभिन्न जन-सुविधा विभागों में दर्ज एवं निराकृत शिकायतों का तुलनात्मक चार्ट'
            : 'Resolution efficiency across primary civic utilities and welfare departments.'}
        </p>

        <div className="space-y-4">
          {categoryCounts.map((cat, i) => (
            <div key={i} className="space-y-1.5 bg-slate-50 p-4 rounded-2xl border border-slate-200/70">
              <div className="flex items-center justify-between text-xs sm:text-sm">
                <span className="font-bold text-slate-800">{cat.name}</span>
                <span className="text-xs font-mono font-bold text-slate-600">
                  {cat.resolved} / {cat.total} ({cat.pct}%)
                </span>
              </div>
              <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-[#0f2d4e] h-full rounded-full transition-all duration-500"
                  style={{ width: `${cat.pct}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
