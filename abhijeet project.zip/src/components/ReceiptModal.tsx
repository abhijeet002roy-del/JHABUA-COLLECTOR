import React, { useState, useEffect } from 'react';
import { X, Printer, CheckCircle2, ShieldCheck, Volume2, VolumeX } from 'lucide-react';
import { Complaint, Language } from '../types';

interface ReceiptModalProps {
  complaint: Complaint | null;
  onClose: () => void;
  lang: Language;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  complaint,
  onClose,
  lang,
}) => {
  const [isSpeaking, setIsSpeaking] = useState(false);

  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  if (!complaint) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleSpeak = () => {
    if (!('speechSynthesis' in window)) return;
    
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textHi = `यह आपकी जनसुनवाई पावती है। शिकायत क्रमांक: ${complaint.complaintNumber}। आवेदक का नाम: ${complaint.name}। विभाग: ${complaint.category}। आपकी शिकायत सफलतापूर्वक दर्ज कर ली गई है।`;
    const textEn = `This is your Jansunwai receipt. Complaint ID: ${complaint.complaintNumber}. Applicant Name: ${complaint.name}. Department: ${complaint.category}. Your complaint has been successfully registered.`;
    
    const utterance = new SpeechSynthesisUtterance(lang === 'hi' ? textHi : textEn);
    utterance.lang = lang === 'hi' ? 'hi-IN' : 'en-IN';
    utterance.rate = 0.9;
    
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto print:static print:bg-white print:p-0 print:block">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 my-8 print:shadow-none print:border-none print:m-0 print:p-0 print:max-w-none">
        {/* Controls - Hidden in print */}
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-200 print:hidden">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            {lang === 'hi' ? 'आधिकारिक पावती पर्ची' : 'Official Acknowledgment Slip'}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleSpeak}
              title={lang === 'hi' ? 'बोलकर सुनाएं' : 'Read Aloud'}
              className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                isSpeaking 
                  ? 'bg-amber-100 border-amber-300 text-amber-800 animate-pulse' 
                  : 'bg-indigo-50 border-indigo-200 text-indigo-700 hover:bg-indigo-100'
              }`}
            >
              {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <button
              onClick={() => {
                const message = `*जनसुनवाई पावती - जिला झाबुआ*\n\n*आवेदक:* ${complaint.name}\n*शिकायत क्र:* ${complaint.complaintNumber}\n*स्थिति:* ${complaint.status}\n*रिमार्क:* ${complaint.officerRemark || 'लंबित'}\n\n*पोर्टल पर स्थिति ट्रैक करें:* ${window.location.origin}`;
                window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#25D366] hover:bg-[#128C7E] text-white text-xs font-bold transition shadow-xs cursor-pointer"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.347-.272.273-1.04 1.02-1.04 2.487 0 1.467 1.064 2.885 1.213 3.083.149.198 2.094 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/>
              </svg>
              <span>{lang === 'hi' ? 'WhatsApp पर भेजें' : 'Share on WhatsApp'}</span>
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#003366] hover:bg-[#002244] text-white text-xs font-bold transition shadow-xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'PDF डाउनलोड / प्रिंट' : 'Download PDF / Print'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Official Slip Content */}
        <div className="border-2 border-slate-800 p-5 sm:p-6 rounded-xl bg-white text-slate-900 relative print:border-0 print:p-0">
          {/* Print Header Logo/Emblem Space */}
          <div className="hidden print:block text-center mb-6">
             <img src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg" alt="Emblem" className="h-16 mx-auto opacity-80" />
          </div>

          {/* Header */}
          <div className="text-center pb-4 border-b-2 border-slate-800 print:border-black">
            <div className="text-xs font-bold text-slate-600 uppercase tracking-widest print:text-black">
              मध्य प्रदेश शासन • जिला प्रशासन झाबुआ
            </div>
            <div className="text-[11px] font-semibold text-slate-500 print:text-black">
              Government of Madhya Pradesh • District Administration Jhabua
            </div>
            <h2 className="text-lg sm:text-xl font-extrabold text-[#003366] mt-1 print:text-black">
              कलेक्टर जनसुनवाई एवं शिकायत पावती पर्ची
            </h2>
            <div className="text-[11px] text-slate-500 font-medium print:text-black">
              Collector Grievance Redressal Acknowledgment Slip
            </div>
          </div>

          {/* Registration Meta */}
          <div className="grid grid-cols-2 gap-2 py-3 border-b border-slate-200 print:border-black text-xs print:text-sm">
            <div>
              <span className="text-slate-500 print:text-slate-800 font-medium">शिकायत क्रमांक (ID):</span>
              <div className="font-mono font-black text-base text-[#003366] print:text-black">
                {complaint.complaintNumber}
              </div>
            </div>
            <div className="text-right">
              <span className="text-slate-500 print:text-slate-800 font-medium">पंजीकरण दिनांक (Date):</span>
              <div className="font-mono font-bold text-slate-800 print:text-black">
                {complaint.createdAt}
              </div>
            </div>
          </div>

          {/* Citizen & Grievance Info Table */}
          <table className="w-full text-xs print:text-sm text-left border-collapse my-3">
            <tbody>
              <tr className="border-b border-slate-100 print:border-slate-300">
                <td className="py-3 pr-2 font-bold text-slate-600 print:text-black w-1/3">आवेदक का नाम (Name):</td>
                <td className="py-3 font-bold text-slate-900 print:text-black">{complaint.name}</td>
              </tr>
              <tr className="border-b border-slate-100 print:border-slate-300">
                <td className="py-3 pr-2 font-bold text-slate-600 print:text-black">मोबाइल नंबर (Mobile):</td>
                <td className="py-3 font-mono font-semibold text-slate-900 print:text-black">+91 {complaint.mobile}</td>
              </tr>
              <tr className="border-b border-slate-100 print:border-slate-300">
                <td className="py-3 pr-2 font-bold text-slate-600 print:text-black">तहसील व ग्राम (Location):</td>
                <td className="py-3 text-slate-900 print:text-black">{complaint.village}, तहसील - {complaint.tehsil}</td>
              </tr>
              <tr className="border-b border-slate-100 print:border-slate-300">
                <td className="py-3 pr-2 font-bold text-slate-600 print:text-black">शिकायत श्रेणी (Category):</td>
                <td className="py-3 font-semibold text-slate-900 print:text-black">{complaint.category}</td>
              </tr>
              <tr className="border-b border-slate-100 print:border-slate-300">
                <td className="py-3 pr-2 font-bold text-slate-600 print:text-black">उत्तरदायी विभाग (Dept):</td>
                <td className="py-3 font-semibold text-[#003366] print:text-black">{complaint.assignedDepartment || 'कलेक्टर जनसुनवाई सेल'}</td>
              </tr>
              <tr className="border-b border-slate-100 print:border-slate-300">
                <td className="py-3 pr-2 font-bold text-slate-600 print:text-black">वर्तमान स्थिति (Status):</td>
                <td className="py-3">
                  <span className="font-bold text-emerald-800 bg-emerald-100 print:bg-transparent print:text-black print:px-0 px-2 py-0.5 rounded-sm">
                    {complaint.status}
                  </span>
                </td>
              </tr>
              <tr className="border-b border-slate-100 print:border-slate-300">
                <td className="py-3 pr-2 font-bold text-slate-600 print:text-black align-top">अधिकारी रिमार्क (Remark):</td>
                <td className="py-3 font-medium text-slate-900 print:text-black">
                  {complaint.officerRemark || 'लंबित (Pending)'}
                </td>
              </tr>
              <tr>
                <td className="py-3 pr-2 font-bold text-slate-600 print:text-black align-top">शिकायत विवरण (Details):</td>
                <td className="py-3 text-slate-800 print:text-black text-[11px] print:text-sm leading-relaxed">
                  {complaint.description}
                </td>
              </tr>
            </tbody>
          </table>

          {/* Timeline in Print (Optional but good for records) */}
          <div className="hidden print:block mt-6 pt-4 border-t-2 border-black">
             <h3 className="font-bold text-black mb-3">कार्रवाई विवरण (Action Timeline)</h3>
             <ul className="text-sm space-y-2">
               {complaint.timeline.map((item, i) => (
                 <li key={i} className="flex gap-4">
                   <div className="w-1/4 font-mono text-xs">{item.timestamp.split(',')[0]}</div>
                   <div className="w-3/4">
                     <span className="font-bold">{lang === 'hi' ? item.titleHi : item.title}</span> - {item.description}
                   </div>
                 </li>
               ))}
             </ul>
          </div>

          {/* Footer Note */}
          <div className="pt-4 mt-6 border-t-2 border-dashed border-slate-300 print:border-black text-[10px] print:text-xs text-slate-600 print:text-black space-y-1">
            <div className="flex items-center gap-1 font-bold text-slate-700 print:text-black">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-700 print:hidden" />
              <span>महत्वपूर्ण निर्देश (Instructions):</span>
            </div>
            <div>
              1. अपनी शिकायत की वर्तमान स्थिति जानने हेतु पोर्टल पर शिकायत क्रमांक{' '}
              <strong>{complaint.complaintNumber}</strong> दर्ज करें अथवा सीएम हेल्पलाइन 181 पर संपर्क करें।
            </div>
            <div>
              2. यह पावती कंप्यूटर जनित है एवं इसके लिए भौतिक हस्ताक्षर की आवश्यकता नहीं है।
            </div>
            <div className="text-right pt-4 font-mono text-[9px] print:text-[10px] text-slate-400 print:text-black">
              Printed on: {new Date().toLocaleDateString('en-IN')} • Jhabua District Administration
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

