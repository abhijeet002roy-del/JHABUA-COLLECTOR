import React, { useState } from 'react';
import { 
  Search, Filter, MapPin, User, Phone, CheckCircle2, 
  Clock, AlertTriangle, MessageSquare, ChevronDown, Award, Check, X, Building, Link, ShieldCheck, UserCheck, Shield, Download, Printer, PieChart, Calendar
} from 'lucide-react';
import { Complaint, ComplaintStatus, Language } from '../types';
import { translations } from '../translations';
import { signInWithGoogle, signInWithEmail, logout, auth, db, handleFirestoreError, OperationType } from '../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { COMPLAINT_CATEGORIES } from '../data/districtInfo';
import { ReceiptModal } from './ReceiptModal';
import { AdminDashboard } from './AdminDashboard';

interface OfficerDeskProps {
  complaints: Complaint[];
  onUpdateComplaint: (complaint: Complaint) => void;
  lang: Language;
  isAdmin: boolean;
}

export const OfficerDesk: React.FC<OfficerDeskProps> = ({ complaints, onUpdateComplaint, lang, isAdmin }) => {
  const t = translations[lang];
  const [filterStatus, setFilterStatus] = useState<ComplaintStatus | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [newRemark, setNewRemark] = useState('');
  const [newStatus, setNewStatus] = useState<ComplaintStatus>('In Progress');
  const [newDepartment, setNewDepartment] = useState('');
  const [printComplaint, setPrintComplaint] = useState<Complaint | null>(null);
  const [activeTab, setActiveTab] = useState<'list' | 'dashboard'>('dashboard');

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    try {
      await signInWithEmail(email, password);
    } catch (err: any) {
      setLoginError(lang === 'hi' ? 'ईमेल या पासवर्ड गलत है।' : 'Invalid email or password.');
    }
  };

  if (!isAdmin) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="bg-white p-10 rounded-3xl shadow-xl border border-slate-200 max-w-md mx-auto">
          <Shield className="w-16 h-16 text-[#0f2d4e] mx-auto mb-4" />
          <h2 className="text-2xl font-black text-[#0a2540] mb-2">
            {lang === 'hi' ? 'अधिकारी लॉगिन' : 'Officer Login'}
          </h2>
          <p className="text-slate-500 mb-6">
            {lang === 'hi' ? 'प्रशासनिक अधिकारी डेस्क पर जाने के लिए कृपया लॉगिन करें।' : 'Please sign in to access the administrative desk.'}
          </p>

          <form onSubmit={handleEmailLogin} className="space-y-4 mb-6">
            {loginError && (
              <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg border border-red-100">
                {loginError}
              </div>
            )}
            <div>
              <input
                type="email"
                placeholder={lang === 'hi' ? 'ईमेल आईडी' : 'Email ID'}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:border-[#0f2d4e] transition"
                required
              />
            </div>
            <div>
              <input
                type="password"
                placeholder={lang === 'hi' ? 'पासवर्ड' : 'Password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:border-[#0f2d4e] transition"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 bg-[#0f2d4e] hover:bg-[#0a2540] text-white rounded-xl font-bold transition shadow-md cursor-pointer active:scale-95"
            >
              {lang === 'hi' ? 'लॉगिन करें' : 'Sign In'}
            </button>
          </form>

          <div className="flex items-center gap-4 my-6">
            <div className="h-px bg-slate-200 flex-1"></div>
            <span className="text-slate-400 text-sm font-medium">{lang === 'hi' ? 'या' : 'OR'}</span>
            <div className="h-px bg-slate-200 flex-1"></div>
          </div>

          <button
            onClick={signInWithGoogle}
            type="button"
            className="w-full flex justify-center items-center gap-3 px-6 py-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-xl font-bold transition shadow-xs cursor-pointer active:scale-95"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 24c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 21.53 7.7 24 12 24z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
              <path fill="#EA4335" d="M12 4.62c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 1.18 14.97 0 12 0 7.7 0 3.99 2.47 2.18 6.07l3.66 2.84c.87-2.6 3.3-4.29 6.16-4.29z" />
            </svg>
            <span>{lang === 'hi' ? 'गूगल से लॉगिन करें' : 'Sign in with Google'}</span>
          </button>
        </div>
      </div>
    );
  }

  const filtered = complaints.filter(c => {
    const matchStatus = filterStatus === 'All' || c.status === filterStatus;
    const q = searchQuery.toLowerCase();
    const matchQuery = 
      c.complaintNumber.toLowerCase().includes(q) || 
      c.name.toLowerCase().includes(q) || 
      c.mobile.includes(q) ||
      c.village.toLowerCase().includes(q);
      
    let matchDate = true;
    if (startDate || endDate) {
      // Attempt to parse the complaint date (handles both "2026-08-10..." and "18 Aug 2026...")
      const complaintDate = new Date(c.createdAt);
      if (!isNaN(complaintDate.getTime())) {
        if (startDate) {
          const start = new Date(startDate);
          start.setHours(0, 0, 0, 0);
          if (complaintDate < start) matchDate = false;
        }
        if (endDate) {
          const end = new Date(endDate);
          end.setHours(23, 59, 59, 999);
          if (complaintDate > end) matchDate = false;
        }
      }
    }
      
    return matchStatus && matchQuery && matchDate;
  });

  const getStatusBadge = (status: ComplaintStatus) => {
    switch (status) {
      case 'Pending': return <span className="bg-slate-100 text-slate-700 border-slate-200 border px-2 py-0.5 rounded-md text-xs font-bold">{lang === 'hi' ? 'लंबित' : 'Pending'}</span>;
      case 'Under Review': return <span className="bg-blue-50 text-blue-700 border-blue-200 border px-2 py-0.5 rounded-md text-xs font-bold">{lang === 'hi' ? 'समीक्षाधीन' : 'Under Review'}</span>;
      case 'In Progress': return <span className="bg-amber-50 text-amber-700 border-amber-200 border px-2 py-0.5 rounded-md text-xs font-bold flex items-center gap-1"><Clock className="w-3 h-3"/> {lang === 'hi' ? 'प्रगति पर' : 'In Progress'}</span>;
      case 'Resolved': return <span className="bg-emerald-50 text-emerald-700 border-emerald-200 border px-2 py-0.5 rounded-md text-xs font-bold flex items-center gap-1"><CheckCircle2 className="w-3 h-3"/> {lang === 'hi' ? 'निराकृत' : 'Resolved'}</span>;
      case 'Rejected': return <span className="bg-rose-50 text-rose-700 border-rose-200 border px-2 py-0.5 rounded-md text-xs font-bold">{lang === 'hi' ? 'अस्वीकृत' : 'Rejected'}</span>;
    }
  };

  const handleUpdate = async (complaint: Complaint) => {
    if (!newRemark.trim()) {
      alert(lang === 'hi' ? 'कृपया कार्रवाई विवरण (रिमार्क) दर्ज करें' : 'Please enter an action remark');
      return;
    }

    const now = new Date();
    const formattedDate = now.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
    
    let title = 'Action Taken by Nodal Officer';
    let titleHi = 'नोडल अधिकारी द्वारा कार्रवाई';
    
    let remarkText = newRemark;
    let actualStatus = newStatus;
    
    if (newDepartment && newDepartment !== complaint.assignedDepartment) {
      title = 'Department Reassigned';
      titleHi = 'विभाग स्थानांतरित';
      remarkText = `Reassigned from ${complaint.assignedDepartment} to ${newDepartment}. ${newRemark}`;
      actualStatus = 'Under Review'; // Reset status when transferring
    } else if (newStatus === 'Resolved') {
      title = 'Grievance Resolved';
      titleHi = 'शिकायत सफलतापूर्वक निराकृत';
    } else if (newStatus === 'Rejected') {
      title = 'Grievance Rejected';
      titleHi = 'शिकायत अस्वीकृत';
    } else if (newStatus === 'Under Review') {
      title = 'Under Scrutiny';
      titleHi = 'समीक्षा हेतु प्रेषित';
    }

    const newEvent = {
      title,
      titleHi,
      timestamp: formattedDate,
      description: remarkText,
      descriptionHi: remarkText, // For simplicity in this demo
      status: actualStatus,
    };

    const updatedTimeline = [newEvent, ...complaint.timeline];

    try {
      const publicRef = doc(db, 'complaints', complaint.id);
      const updates: any = {
        status: actualStatus,
        officerRemark: remarkText,
        timeline: updatedTimeline,
      };

      if (newDepartment && newDepartment !== complaint.assignedDepartment) {
        updates.assignedDepartment = newDepartment;
      }

      if (actualStatus === 'Resolved') {
        updates.resolvedAt = formattedDate;
      }

      await updateDoc(publicRef, updates);

      // Local state update isn't strictly necessary since we listen to snapshot in App.tsx,
      // but we do it to clear the form immediately.
      setUpdatingId(null);
      setNewRemark('');
    } catch (e) {
      console.error(e);
      handleFirestoreError(e, OperationType.UPDATE, `complaints/${complaint.id}`);
      alert(lang === 'hi' ? 'अपडेट विफल हुआ' : 'Update failed');
    }
  };

  const handleExportCSV = () => {
    if (filtered.length === 0) {
      alert(lang === 'hi' ? 'निर्यात करने के लिए कोई डेटा नहीं है।' : 'No data to export.');
      return;
    }

    const headers = [
      'Complaint ID',
      'Date Submitted',
      'Category',
      'Applicant Name',
      'Mobile Number',
      'Tehsil',
      'Village',
      'Status',
      'Priority',
      'Description',
      'Officer Remark'
    ];

    const escapeCSV = (val: string | undefined) => {
      if (!val) return '""';
      return `"${String(val).replace(/"/g, '""')}"`;
    };

    const rows = filtered.map(c => [
      escapeCSV(c.complaintNumber),
      escapeCSV(c.createdAt),
      escapeCSV(c.category),
      escapeCSV(c.name),
      escapeCSV(c.mobile),
      escapeCSV(c.tehsil),
      escapeCSV(c.village),
      escapeCSV(c.status),
      escapeCSV(c.priority),
      escapeCSV(c.description),
      escapeCSV(c.officerRemark)
    ].join(','));

    const csvContent = [headers.join(','), ...rows].join('\n');
    
    // Add UTF-8 BOM to ensure Excel reads Hindi characters correctly
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Grievances_Export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <>
      <div className="max-w-6xl mx-auto px-4 py-8 space-y-6 print:hidden">
        {/* Header */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200/90 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-[#0f2d4e] text-white flex items-center justify-center shrink-0 shadow-md">
            <Award className="w-7 h-7 text-amber-400" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-[#0a2540]">
              {t.officerTitle}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              {lang === 'hi' ? 'प्राप्त शिकायतों की समीक्षा एवं निराकरण करें' : 'Review and resolve citizen grievances securely.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 flex items-center gap-3 text-sm font-bold text-slate-700">
             <UserCheck className="w-4 h-4 text-emerald-600" />
             <span>{auth.currentUser?.email}</span>
          </div>
          <button 
            onClick={logout}
            className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl font-bold text-xs transition cursor-pointer"
          >
            {lang === 'hi' ? 'लॉगआउट' : 'Logout'}
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-xl w-fit">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex items-center gap-2 px-5 py-2 rounded-lg font-bold text-sm transition ${activeTab === 'dashboard' ? 'bg-white text-[#0f2d4e] shadow-xs' : 'text-slate-500 hover:text-slate-700 cursor-pointer'}`}
        >
          <PieChart className="w-4 h-4" />
          <span>{lang === 'hi' ? 'डैशबोर्ड' : 'Dashboard'}</span>
        </button>
        <button
          onClick={() => setActiveTab('list')}
          className={`flex items-center gap-2 px-5 py-2 rounded-lg font-bold text-sm transition ${activeTab === 'list' ? 'bg-white text-[#0f2d4e] shadow-xs' : 'text-slate-500 hover:text-slate-700 cursor-pointer'}`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>{lang === 'hi' ? 'शिकायत सूची' : 'Complaints List'}</span>
        </button>
      </div>

      {activeTab === 'dashboard' ? (
        <AdminDashboard complaints={complaints} lang={lang} />
      ) : (
        <>
          {/* Filters */}
          <div className="flex flex-col gap-4">
            <div className="flex flex-col sm:flex-row gap-4 items-center">
              <div className="relative w-full sm:flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={lang === 'hi' ? 'शिकायत नंबर, नाम या ग्राम खोजें...' : 'Search ID, name, or village...'}
                  className="w-full pl-10 pr-4 py-2.5 text-sm font-medium rounded-xl border border-slate-300 focus:border-[#0f2d4e] outline-hidden bg-white shadow-2xs"
                />
              </div>
              <div className="flex w-full sm:w-auto gap-4">
                <div className="relative w-full sm:w-48 shrink-0">
                  <Filter className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <select
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value as ComplaintStatus | 'All')}
                    className="w-full pl-10 pr-4 py-2.5 text-sm font-bold rounded-xl border border-slate-300 focus:border-[#0f2d4e] outline-hidden bg-white shadow-2xs cursor-pointer appearance-none"
                  >
                    <option value="All">{lang === 'hi' ? 'सभी स्थितियाँ (All)' : 'All Status'}</option>
                    <option value="Pending">{lang === 'hi' ? 'लंबित (Pending)' : 'Pending'}</option>
                    <option value="Under Review">{lang === 'hi' ? 'समीक्षाधीन (Review)' : 'Under Review'}</option>
                    <option value="In Progress">{lang === 'hi' ? 'प्रगति पर (Progress)' : 'In Progress'}</option>
                    <option value="Resolved">{lang === 'hi' ? 'निराकृत (Resolved)' : 'Resolved'}</option>
                  </select>
                  <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5 pointer-events-none" />
                </div>
                
                <button
                  onClick={handleExportCSV}
                  className="shrink-0 inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl font-bold text-sm transition cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span className="hidden sm:inline">{lang === 'hi' ? 'CSV डाउनलोड' : 'Export CSV'}</span>
                </button>
              </div>
            </div>

            {/* Date Range Filter Row */}
            <div className="flex flex-col sm:flex-row gap-4 sm:items-center bg-slate-50 p-3 rounded-xl border border-slate-200/80">
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <Calendar className="w-4 h-4 text-slate-400" />
                <span className="text-xs font-bold text-slate-500 whitespace-nowrap">{lang === 'hi' ? 'दिनांक से:' : 'From Date:'}</span>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full sm:w-auto px-3 py-2 text-sm font-medium rounded-lg border border-slate-300 focus:border-[#0f2d4e] outline-hidden bg-white shadow-2xs cursor-pointer"
                />
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <span className="text-xs font-bold text-slate-500 whitespace-nowrap">{lang === 'hi' ? 'तक:' : 'To Date:'}</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full sm:w-auto px-3 py-2 text-sm font-medium rounded-lg border border-slate-300 focus:border-[#0f2d4e] outline-hidden bg-white shadow-2xs cursor-pointer"
                />
              </div>
              {(startDate || endDate) && (
                <button
                  onClick={() => { setStartDate(''); setEndDate(''); }}
                  className="text-xs font-bold text-rose-600 hover:text-rose-800 underline ml-auto sm:ml-4 cursor-pointer"
                >
                  {lang === 'hi' ? 'फ़िल्टर हटाएं' : 'Clear Dates'}
                </button>
              )}
            </div>
          </div>

          {/* List */}
          <div className="space-y-4">
            {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center border border-slate-200">
            <ShieldCheck className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <div className="text-slate-500 font-medium">
              {lang === 'hi' ? 'कोई रिकॉर्ड नहीं मिला।' : 'No records found.'}
            </div>
          </div>
        ) : (
          filtered.map((c) => (
            <div key={c.id} className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs hover:border-slate-300 transition-all">
              <div className="flex flex-col md:flex-row gap-5">
                {/* Left Col - Details */}
                <div className="flex-1 space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono font-black text-[#0f2d4e] tracking-tight">{c.complaintNumber}</span>
                        {c.priority === 'Urgent' && (
                          <span className="relative bg-rose-100 text-rose-800 text-[10px] font-black px-1.5 py-0.5 rounded flex items-center gap-0.5">
                            <span className="absolute -inset-1 rounded-full bg-rose-400/30 animate-ping"></span>
                            <span className="relative z-10 flex items-center gap-0.5">
                              <span>⚡</span> {lang === 'hi' ? 'अति-महत्वपूर्ण' : 'Urgent'}
                            </span>
                          </span>
                        )}
                      </div>
                      <div className="text-sm font-bold text-slate-800">{c.category}</div>
                    </div>
                    {getStatusBadge(c.status)}
                  </div>

                  <div className="grid grid-cols-2 gap-y-2 gap-x-4 text-xs">
                    <div className="flex items-center gap-1.5 text-slate-600">
                      <User className="w-3.5 h-3.5" />
                      <span className="font-semibold truncate">{c.name}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-600">
                      <Phone className="w-3.5 h-3.5" />
                      <span className="font-mono">{c.mobile}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-600">
                      <MapPin className="w-3.5 h-3.5" />
                      <span className="truncate">{c.village}, {c.tehsil}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-600">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{c.createdAt.split(',')[0]}</span>
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-sm text-slate-700 leading-relaxed font-medium">
                    "{c.description}"
                  </div>
                </div>

                {/* Right Col - Action */}
                <div className="w-full md:w-72 shrink-0 border-t md:border-t-0 md:border-l border-slate-100 pt-4 md:pt-0 md:pl-5 flex flex-col justify-center">
                  {updatingId === c.id ? (
                    <div className="space-y-3 bg-blue-50/50 p-3 rounded-xl border border-blue-100">
                      <div>
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Reassign Dept (Optional)</label>
                        <select
                          value={newDepartment}
                          onChange={(e) => setNewDepartment(e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs font-medium rounded-lg border border-slate-300 focus:border-[#0f2d4e] outline-hidden bg-white mb-2"
                        >
                          <option value="">-- Keep Current Dept --</option>
                          {COMPLAINT_CATEGORIES.map(cat => (
                            <option key={cat.id} value={cat.dept}>{cat.dept}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">New Status</label>
                        <select
                          value={newStatus}
                          onChange={(e) => setNewStatus(e.target.value as ComplaintStatus)}
                          className="w-full px-2.5 py-1.5 text-xs font-bold rounded-lg border border-slate-300 focus:border-[#0f2d4e] outline-hidden bg-white"
                        >
                          <option value="Under Review">Under Review</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Resolved">Resolved</option>
                          <option value="Rejected">Rejected</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Action Remark</label>
                        <textarea
                          rows={2}
                          value={newRemark}
                          onChange={(e) => setNewRemark(e.target.value)}
                          placeholder="e.g., Team dispatched..."
                          className="w-full px-2.5 py-1.5 text-xs font-medium rounded-lg border border-slate-300 focus:border-[#0f2d4e] outline-hidden bg-white"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleUpdate(c)}
                          className="flex-1 bg-[#0a664c] hover:bg-[#08533b] text-white text-xs font-bold py-2 rounded-lg transition cursor-pointer"
                        >
                          Save
                        </button>
                        <button
                          onClick={() => setUpdatingId(null)}
                          className="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold py-2 rounded-lg transition cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col gap-3 h-full justify-center">
                      {c.status !== 'Resolved' && c.status !== 'Rejected' && (
                        <button
                          onClick={() => {
                            setUpdatingId(c.id);
                            setNewStatus(c.status === 'Pending' ? 'Under Review' : c.status);
                            setNewRemark('');
                            setNewDepartment(c.assignedDepartment);
                          }}
                          className="w-full flex items-center justify-center gap-1.5 py-2.5 bg-[#0f2d4e] hover:bg-[#0a2540] text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-amber-300" />
                          <span>{lang === 'hi' ? 'कार्रवाई अपडेट करें' : 'Update Action'}</span>
                        </button>
                      )}
                      
                      <button
                        onClick={() => setPrintComplaint(c)}
                        className="w-full flex items-center justify-center gap-1.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition border border-slate-200 cursor-pointer"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>{lang === 'hi' ? 'पर्ची प्रिंट करें' : 'Print Slip'}</span>
                      </button>

                      {c.officerRemark && (
                        <div className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                          <span className="font-bold text-slate-800 block mb-0.5">Last Remark:</span>
                          <span className="line-clamp-2 italic">"{c.officerRemark}"</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      </>
      )}
    </div>
    
    {printComplaint && (
      <ReceiptModal complaint={printComplaint} onClose={() => setPrintComplaint(null)} lang={lang} />
    )}
  </>
  );
};
