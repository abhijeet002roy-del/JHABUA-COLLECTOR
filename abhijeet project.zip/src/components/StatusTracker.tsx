import React, { useState, useEffect } from 'react';
import { 
  Search, Clock, CheckCircle, AlertCircle, User, MapPin, Building, Printer, 
  Calendar, ShieldCheck, Sparkles, AlertTriangle, FileCheck, CheckCircle2, 
  FileText, Activity, Check, Layers, ArrowRight, ShieldAlert, BadgeHelp,
  Volume2, VolumeX
} from 'lucide-react';
import { Complaint, Language, ComplaintStatus } from '../types';
import { translations } from '../translations';

interface StatusTrackerProps {
  complaints: Complaint[];
  lang: Language;
  initialQuery?: string;
  onOpenReceipt: (complaint: Complaint) => void;
}

export const StatusTracker: React.FC<StatusTrackerProps> = ({
  complaints,
  lang,
  initialQuery = '',
  onOpenReceipt,
}) => {
  const t = translations[lang];
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [searched, setSearched] = useState(Boolean(initialQuery));
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Cleanup speech synthesis on unmount
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleSpeak = (complaint: Complaint, stageDesc: string) => {
    if (!('speechSynthesis' in window)) return;
    
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textHi = `आपकी शिकायत क्रमांक ${complaint.complaintNumber} की वर्तमान स्थिति है: ${complaint.status}। ${stageDesc}`;
    const textEn = `The current status of your complaint number ${complaint.complaintNumber} is: ${complaint.status}. ${stageDesc}`;
    
    const utterance = new SpeechSynthesisUtterance(lang === 'hi' ? textHi : textEn);
    utterance.lang = lang === 'hi' ? 'hi-IN' : 'en-IN';
    utterance.rate = 0.9;
    
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(() => {
    if (initialQuery) {
      const q = initialQuery.trim().toLowerCase();
      return (
        complaints.find(
          (c) =>
            c.complaintNumber.toLowerCase() === q ||
            c.mobile.replace(/\D/g, '') === q.replace(/\D/g, '')
        ) || null
      );
    }
    return null;
  });

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const q = searchQuery.trim().toLowerCase();
    if (!q) return;

    setSearched(true);
    const cleanMobile = q.replace(/\D/g, '');

    const found = complaints.find(
      (c) =>
        c.complaintNumber.toLowerCase() === q ||
        (cleanMobile.length >= 8 && c.mobile.includes(cleanMobile))
    );

    setSelectedComplaint(found || null);
  };

  const getStatusBadge = (status: ComplaintStatus) => {
    switch (status) {
      case 'Resolved':
        return (
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-xs">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'hi' ? 'निराकृत (Resolved)' : 'Resolved'}</span>
          </span>
        );
      case 'In Progress':
        return (
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-black bg-sky-100 text-sky-800 border border-sky-300 shadow-xs">
            <Clock className="w-3.5 h-3.5 text-sky-600 animate-spin" />
            <span>{lang === 'hi' ? 'प्रगति पर (In Progress)' : 'In Progress'}</span>
          </span>
        );
      case 'Under Review':
        return (
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-black bg-amber-100 text-amber-900 border border-amber-300 shadow-xs">
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>{lang === 'hi' ? 'समीक्षाधीन (Under Review)' : 'Under Review'}</span>
          </span>
        );
      case 'Rejected':
        return (
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-black bg-rose-100 text-rose-800 border border-rose-300 shadow-xs">
            <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
            <span>{lang === 'hi' ? 'अस्वीकृत / निरस्त (Rejected)' : 'Rejected'}</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-black bg-slate-200 text-slate-800 border border-slate-300 shadow-xs">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            <span>{lang === 'hi' ? 'लंबित (Pending)' : 'Pending'}</span>
          </span>
        );
    }
  };

  // Helper to compute progress step status
  const getLifecycleStageInfo = (status: ComplaintStatus) => {
    switch (status) {
      case 'Pending':
        return {
          currentStep: 1,
          percent: 25,
          color: 'from-[#0f2d4e] to-sky-600',
          textHi: 'चरण 1/4: शिकायत पंजीकृत (विभाग को प्रेषण प्रक्रियाधीन)',
          textEn: 'Stage 1 of 4: Grievance Registered (Dispatch in progress)',
          isRejected: false,
        };
      case 'Under Review':
        return {
          currentStep: 2,
          percent: 50,
          color: 'from-[#0f2d4e] via-sky-600 to-amber-500',
          textHi: 'चरण 2/4: विभागीय जांच व समीक्षा जारी',
          textEn: 'Stage 2 of 4: Scrutiny & Nodal Review in Progress',
          isRejected: false,
        };
      case 'In Progress':
        return {
          currentStep: 3,
          percent: 75,
          color: 'from-[#0f2d4e] via-amber-500 to-blue-600',
          textHi: 'चरण 3/4: मैदानी कार्रवाई व निराकरण प्रक्रियाधीन',
          textEn: 'Stage 3 of 4: Field Action & Redressal in Progress',
          isRejected: false,
        };
      case 'Resolved':
        return {
          currentStep: 4,
          percent: 100,
          color: 'from-[#0f2d4e] via-sky-600 to-emerald-600',
          textHi: 'चरण 4/4: समस्या का पूर्ण समाधान व निराकरण संपन्न',
          textEn: 'Stage 4 of 4: Grievance Successfully Resolved',
          isRejected: false,
        };
      case 'Rejected':
        return {
          currentStep: 2,
          percent: 50,
          color: 'from-[#0f2d4e] to-rose-600',
          textHi: 'समीक्षा उपरांत शिकायत निरस्त / अस्वीकृत की गई',
          textEn: 'Grievance Rejected after scrutiny',
          isRejected: true,
        };
    }
  };

  const stepsConfig = [
    {
      id: 1,
      titleHi: 'पंजीकृत (Filed)',
      titleEn: 'Grievance Filed',
      descHi: 'कलेक्टर पोर्टल पर शिकायत दर्ज एवं टोकन जारी',
      descEn: 'Registered on Collector Portal with ID',
      icon: FileText,
    },
    {
      id: 2,
      titleHi: 'विभागीय समीक्षा',
      titleEn: 'Under Review',
      descHi: 'संबंधित नोडल अधिकारी को प्रेषित व प्राथमिक जांच',
      descEn: 'Forwarded to Nodal Dept for scrutiny',
      icon: Layers,
    },
    {
      id: 3,
      titleHi: 'कार्रवाई जारी',
      titleEn: 'In Progress',
      descHi: 'मौका मुआयना, जांच व फील्ड स्तर पर समाधान',
      descEn: 'Field inspection & corrective action',
      icon: Activity,
    },
    {
      id: 4,
      titleHi: 'सफल निराकरण',
      titleEn: 'Resolved',
      descHi: 'कार्रवाई पूर्ण, समाधान प्रतिवेदन एवं प्रकरण बंद',
      descEn: 'Action completed & closed with report',
      icon: CheckCircle2,
    },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      {/* Search Header Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200/90">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-[#0f2d4e] bg-slate-100 px-3 py-1 rounded-full mb-2.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>{lang === 'hi' ? 'पारदर्शी जनसुनवाई ट्रैकिंग' : 'Transparent Jansunwai Tracking'}</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-[#0a2540]">
            {t.trackTitle}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {t.trackSub}
          </p>
        </div>

        <form onSubmit={handleSearch} className="mt-5 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.trackInputPlaceholder}
              className="w-full pl-12 pr-4 py-3 rounded-2xl border border-slate-300 focus:border-[#0f2d4e] focus:ring-2 focus:ring-[#0f2d4e]/20 outline-hidden font-medium text-sm text-slate-900 bg-white"
            />
          </div>
          <button
            type="submit"
            className="px-7 py-3 bg-[#0f2d4e] hover:bg-[#0a2540] text-white font-black text-sm rounded-2xl transition shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-98"
          >
            <Search className="w-4 h-4 text-amber-400" />
            <span>{t.searchBtn}</span>
          </button>
        </form>

        {/* Quick Example Links */}
        <div className="mt-4 flex items-center gap-2 flex-wrap text-xs text-slate-500">
          <span className="font-bold">{lang === 'hi' ? 'त्वरित उदाहरण:' : 'Quick examples:'}</span>
          {complaints.slice(0, 4).map((c) => (
            <button
              key={c.id}
              onClick={() => {
                setSearchQuery(c.complaintNumber);
                setSelectedComplaint(c);
                setSearched(true);
              }}
              className="px-3 py-1 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#0f2d4e] font-mono font-bold transition cursor-pointer border border-slate-200"
            >
              {c.complaintNumber}
            </button>
          ))}
        </div>
      </div>

      {/* Result Display */}
      {searched && !selectedComplaint && (
        <div className="bg-white rounded-3xl p-10 text-center shadow-sm border border-rose-200">
          <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-500 flex items-center justify-center mx-auto mb-3">
            <AlertTriangle className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-800">
            {lang === 'hi' ? 'कोई शिकायत रिकॉर्ड नहीं मिला' : 'No Grievance Record Found'}
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-md mx-auto">
            {t.noComplaintFound}
          </p>
        </div>
      )}

      {selectedComplaint && (() => {
        const stageInfo = getLifecycleStageInfo(selectedComplaint.status);

        return (
          <div className="space-y-6">
            {/* Main Status Hero Card */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200/90 relative overflow-hidden">
              {/* Watermark Seal */}
              <div className="absolute right-4 bottom-4 opacity-5 pointer-events-none select-none font-black text-9xl text-slate-900 font-mono">
                JHB
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      {lang === 'hi' ? 'शिकायत क्रमांक:' : 'Complaint No:'}
                    </span>
                    <span className="font-mono text-xl sm:text-2xl font-black text-[#0f2d4e]">
                      {selectedComplaint.complaintNumber}
                    </span>
                    {selectedComplaint.priority === 'Urgent' && (
                      <span className="relative flex items-center gap-1 text-[11px] font-bold bg-amber-100 text-amber-900 px-2.5 py-0.5 rounded-full border border-amber-300">
                        <span className="absolute -inset-1 rounded-full bg-amber-400/20 animate-ping"></span>
                        <span className="relative z-10 flex items-center gap-1">
                          ⚡ {lang === 'hi' ? 'अति आवश्यक (Urgent)' : 'Urgent Priority'}
                        </span>
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-500 mt-1 flex items-center gap-2 font-mono">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>{lang === 'hi' ? 'पंजीकरण दिनांक:' : 'Registered On:'} {selectedComplaint.createdAt}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <button
                    onClick={() => handleSpeak(selectedComplaint, lang === 'hi' ? stageInfo.textHi : stageInfo.textEn)}
                    className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition cursor-pointer border shadow-2xs ${
                      isSpeaking 
                        ? 'bg-amber-100 text-amber-800 border-amber-300 animate-pulse'
                        : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border-indigo-200'
                    }`}
                    title={lang === 'hi' ? 'स्थिति सुनें' : 'Listen Status'}
                  >
                    {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                    <span className="hidden sm:inline">{isSpeaking ? (lang === 'hi' ? 'रोकें' : 'Stop') : (lang === 'hi' ? 'सुनें' : 'Listen')}</span>
                  </button>
                  {getStatusBadge(selectedComplaint.status)}
                  <button
                    onClick={() => onOpenReceipt(selectedComplaint)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition cursor-pointer border border-slate-200 shadow-2xs"
                  >
                    <Printer className="w-3.5 h-3.5 text-slate-600" />
                    <span>{lang === 'hi' ? 'पावती रसीद' : 'Official Slip'}</span>
                  </button>
                </div>
              </div>

              {/* DYNAMIC LIFECYCLE PROGRESS STEPPER */}
              <div className="py-6 border-b border-slate-100">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-slate-100 rounded-lg text-[#0f2d4e]">
                      <Activity className="w-4 h-4" />
                    </div>
                    <span className="text-xs sm:text-sm font-black text-[#0a2540]">
                      {lang === 'hi' ? 'शिकायत जीवन-चक्र प्रगति (Redressal Lifecycle)' : 'Grievance Resolution Lifecycle Progress'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                      stageInfo.isRejected 
                        ? 'bg-rose-50 text-rose-700 border-rose-200'
                        : selectedComplaint.status === 'Resolved'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-sky-50 text-sky-800 border-sky-200'
                    }`}>
                      {lang === 'hi' ? stageInfo.textHi : stageInfo.textEn}
                    </span>
                    <span className="text-xs font-black text-slate-500 font-mono">
                      {stageInfo.percent}%
                    </span>
                  </div>
                </div>

                {/* Stepper Bar Container */}
                <div className="mt-6 sm:mt-8 px-2 sm:px-6">
                  {/* Progress Line Track */}
                  <div className="relative">
                    {/* Background grey bar */}
                    <div className="absolute top-1/2 left-0 right-0 -translate-y-1/2 h-1.5 bg-slate-200 rounded-full z-0" />
                    
                    {/* Dynamic colored active progress fill */}
                    <div 
                      className={`absolute top-1/2 left-0 -translate-y-1/2 h-1.5 rounded-full transition-all duration-700 ease-out z-0 bg-gradient-to-r ${stageInfo.color}`}
                      style={{ 
                        width: stageInfo.isRejected 
                          ? '40%' 
                          : `${((stageInfo.currentStep - 1) / (stepsConfig.length - 1)) * 100}%` 
                      }}
                    />

                    {/* Step nodes grid */}
                    <div className="relative z-10 flex items-center justify-between">
                      {stepsConfig.map((step) => {
                        const isCompleted = !stageInfo.isRejected && stageInfo.currentStep > step.id;
                        const isCurrent = !stageInfo.isRejected && stageInfo.currentStep === step.id;
                        const isFailedAtStep = stageInfo.isRejected && step.id === 2;
                        const isPending = !isCompleted && !isCurrent && !isFailedAtStep;
                        const StepIcon = step.icon;

                        let nodeBg = 'bg-white border-slate-300 text-slate-400';
                        if (isCompleted) {
                          nodeBg = 'bg-emerald-600 border-emerald-600 text-white ring-4 ring-emerald-100 shadow-sm';
                        } else if (isCurrent) {
                          if (selectedComplaint.status === 'Resolved') {
                            nodeBg = 'bg-emerald-600 border-emerald-600 text-white ring-4 ring-emerald-200 shadow-md animate-pulse';
                          } else {
                            nodeBg = 'bg-[#0f2d4e] border-[#0f2d4e] text-white ring-4 ring-blue-100 shadow-md animate-pulse';
                          }
                        } else if (isFailedAtStep) {
                          nodeBg = 'bg-rose-600 border-rose-600 text-white ring-4 ring-rose-100 shadow-md';
                        }

                        return (
                          <div key={step.id} className="flex flex-col items-center group">
                            {/* Circle Node */}
                            <div 
                              className={`w-9 h-9 sm:w-11 sm:h-11 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${nodeBg}`}
                            >
                              {isCompleted ? (
                                <Check className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
                              ) : isFailedAtStep ? (
                                <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                              ) : (
                                <StepIcon className="w-4 h-4 sm:w-5 sm:h-5" />
                              )}
                            </div>

                            {/* Label underneath */}
                            <div className="mt-2.5 text-center max-w-[70px] sm:max-w-[130px]">
                              <div className={`text-[10px] sm:text-xs font-black leading-tight ${
                                isCompleted || isCurrent ? 'text-slate-900 font-extrabold' : isFailedAtStep ? 'text-rose-700' : 'text-slate-400'
                              }`}>
                                {lang === 'hi' ? step.titleHi : step.titleEn}
                              </div>
                              <div className="hidden sm:block text-[10px] text-slate-500 mt-0.5 leading-snug">
                                {lang === 'hi' ? step.descHi : step.descEn}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Rejection Notice Banner if applicable */}
                {selectedComplaint.status === 'Rejected' && (
                  <div className="mt-5 p-4 rounded-2xl bg-rose-50 border border-rose-200 flex items-start gap-3">
                    <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <div className="text-xs font-bold text-rose-900">
                        {lang === 'hi' ? 'शिकायत निराकरण नहीं हो सका (अस्वीकृत/निरस्त)' : 'Grievance could not be processed (Rejected)'}
                      </div>
                      <div className="text-xs text-rose-700 mt-0.5">
                        {selectedComplaint.officerRemark || (lang === 'hi' ? 'यह शिकायत जांच उपरांत अपात्र अथवा असंगत पाई गई।' : 'This grievance was found non-actionable upon departmental verification.')}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Applicant & Location Details Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-5 border-b border-slate-100 text-xs sm:text-sm">
                <div className="flex items-start gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200/60">
                  <User className="w-4 h-4 text-[#0f2d4e] mt-0.5 shrink-0" />
                  <div>
                    <div className="text-[11px] text-slate-500 font-semibold uppercase">{lang === 'hi' ? 'आवेदक का नाम' : 'Applicant Name'}</div>
                    <div className="font-bold text-slate-900">{selectedComplaint.name}</div>
                    <div className="text-xs text-slate-500 font-mono mt-0.5">📞 +91 {selectedComplaint.mobile}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200/60">
                  <MapPin className="w-4 h-4 text-[#0f2d4e] mt-0.5 shrink-0" />
                  <div>
                    <div className="text-[11px] text-slate-500 font-semibold uppercase">{lang === 'hi' ? 'तहसील व ग्राम' : 'Tehsil & Village'}</div>
                    <div className="font-bold text-slate-900">{selectedComplaint.village}, {selectedComplaint.tehsil}</div>
                    {selectedComplaint.address && (
                      <div className="text-xs text-slate-500 mt-0.5 line-clamp-1">{selectedComplaint.address}</div>
                    )}
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200/60">
                  <Building className="w-4 h-4 text-[#0f2d4e] mt-0.5 shrink-0" />
                  <div>
                    <div className="text-[11px] text-slate-500 font-semibold uppercase">{t.assignedDept}</div>
                    <div className="font-bold text-[#0f2d4e]">
                      {selectedComplaint.assignedDepartment || 'कलेक्टर जनसुनवाई प्रकोष्ठ'}
                    </div>
                    {selectedComplaint.assignedOfficer && (
                      <div className="text-xs text-slate-600 mt-0.5">
                        👤 {selectedComplaint.assignedOfficer}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Grievance Description */}
              <div className="py-4">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
                  {lang === 'hi' ? 'शिकायत का विषय एवं विवरण' : 'Grievance Description'}
                </div>
                <div className="text-sm font-bold text-[#0a2540] mb-2 flex items-center gap-1.5">
                  <FileCheck className="w-4 h-4 text-[#0f2d4e]" />
                  <span>{selectedComplaint.category}</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-700 bg-slate-50 p-4 rounded-2xl border border-slate-200/80 leading-relaxed whitespace-pre-wrap">
                  {selectedComplaint.description}
                </p>
              </div>

              {/* Latest Officer Remarks */}
              {selectedComplaint.officerRemark && (
                <div className="bg-emerald-50/90 border border-emerald-200 rounded-2xl p-4 sm:p-5 mt-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-900 uppercase tracking-wide mb-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                    <span>{t.officerRemarks}</span>
                  </div>
                  <p className="text-xs sm:text-sm text-emerald-950 font-medium leading-relaxed">
                    {selectedComplaint.officerRemark}
                  </p>
                </div>
              )}
            </div>

            {/* Detailed Timeline Tracker */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200/90">
              <h3 className="text-base sm:text-lg font-extrabold text-[#0a2540] mb-6 flex items-center gap-2">
                <Clock className="w-5 h-5 text-sky-600" />
                <span>{t.statusTimeline}</span>
              </h3>

              <div className="relative pl-6 sm:pl-8 space-y-5 before:absolute before:left-3 sm:before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                {selectedComplaint.timeline.map((step, idx) => (
                  <div key={idx} className="relative group">
                    <div className={`absolute -left-6 sm:-left-8 top-1 w-6 h-6 rounded-full border-2 flex items-center justify-center text-xs font-bold ${
                      step.status === 'Resolved'
                        ? 'bg-emerald-600 border-white text-white shadow-xs'
                        : step.status === 'In Progress'
                        ? 'bg-sky-600 border-white text-white'
                        : 'bg-[#0f2d4e] border-white text-white'
                    }`}>
                      {idx + 1}
                    </div>

                    <div className="bg-slate-50 hover:bg-slate-100 transition p-4 rounded-2xl border border-slate-200/80">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                        <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                          {lang === 'hi' ? step.titleHi : step.title}
                        </h4>
                        <span className="text-xs text-slate-500 font-mono">
                          {step.timestamp}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm text-slate-600 mt-1">
                        {lang === 'hi' ? step.descriptionHi : step.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
};

