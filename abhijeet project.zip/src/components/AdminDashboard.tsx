import React from 'react';
import { 
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
  AreaChart, Area
} from 'recharts';
import { AlertCircle, Clock } from 'lucide-react';
import { Complaint, Language } from '../types';

interface AdminDashboardProps {
  complaints: Complaint[];
  lang: Language;
}

const COLORS = ['#0f2d4e', '#059669', '#d97706', '#dc2626', '#475569'];

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ complaints, lang }) => {
  // Aggregate statistics
  const total = complaints.length;
  const resolved = complaints.filter(c => c.status === 'Resolved').length;
  const pending = complaints.filter(c => c.status === 'Pending' || c.status === 'Under Review' || c.status === 'In Progress').length;
  const urgentCount = complaints.filter(c => c.priority === 'Urgent' && c.status !== 'Resolved' && c.status !== 'Rejected').length;
  const urgentComplaints = complaints.filter(c => c.priority === 'Urgent' && c.status !== 'Resolved' && c.status !== 'Rejected').slice(0, 5);

  // Find complaints that are pending for more than 7 days
  const now = new Date();
  const delayedComplaints = complaints.filter(c => {
    if (c.status === 'Resolved' || c.status === 'Rejected') return false;
    
    try {
      const parts = c.createdAt.split(',');
      if (parts.length > 0) {
        const dateStr = parts[0].trim();
        const createdDate = new Date(dateStr);
        if (!isNaN(createdDate.getTime())) {
          const diffTime = Math.abs(now.getTime() - createdDate.getTime());
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          return diffDays > 7;
        }
      }
    } catch(e) {}
    
    return false;
  });

  const delayedCount = delayedComplaints.length;
  
  // Department/Category stats
  const categoryCount: Record<string, number> = {};
  complaints.forEach(c => {
    categoryCount[c.category] = (categoryCount[c.category] || 0) + 1;
  });
  const categoryData = Object.keys(categoryCount).map(key => ({
    name: key,
    value: categoryCount[key]
  })).sort((a, b) => b.value - a.value).slice(0, 5); // Top 5

  // Tehsil stats
  const tehsilCount: Record<string, number> = {};
  complaints.forEach(c => {
    tehsilCount[c.tehsil] = (tehsilCount[c.tehsil] || 0) + 1;
  });
  const tehsilData = Object.keys(tehsilCount).map(key => ({
    name: key,
    value: tehsilCount[key]
  })).sort((a, b) => b.value - a.value);

  // Status stats for Pie Chart
  const statusData = [
    { name: lang === 'hi' ? 'निराकृत (Resolved)' : 'Resolved', value: resolved },
    { name: lang === 'hi' ? 'लंबित (Pending/Process)' : 'Pending', value: pending },
    { name: lang === 'hi' ? 'अस्वीकृत (Rejected)' : 'Rejected', value: complaints.filter(c => c.status === 'Rejected').length }
  ].filter(d => d.value > 0);

  // Trend over time (By Date)
  const dateCount: Record<string, number> = {};
  complaints.forEach(c => {
    try {
      const parts = c.createdAt.split(',');
      if (parts.length > 0) {
        const dateStr = parts[0].trim();
        dateCount[dateStr] = (dateCount[dateStr] || 0) + 1;
      }
    } catch(e) {}
  });
  
  const trendData = Object.keys(dateCount)
    .map(date => ({
      date,
      dateObj: new Date(date),
      count: dateCount[date]
    }))
    .filter(d => !isNaN(d.dateObj.getTime()))
    .sort((a, b) => a.dateObj.getTime() - b.dateObj.getTime())
    .map(d => ({
      name: d.date.substring(0, 6), // e.g., "17 Aug"
      Complaints: d.count
    }));

  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-200 mb-8 shadow-sm">
      <div className="mb-6 pb-4 border-b border-slate-100 flex items-center justify-between">
        <h3 className="text-lg font-black text-[#0f2d4e]">
          {lang === 'hi' ? 'जिला एनालिटिक्स डैशबोर्ड' : 'District Analytics Dashboard'}
        </h3>
        <div className="text-sm font-medium text-slate-500 bg-slate-100 px-3 py-1 rounded-lg">
          Total: <span className="font-bold text-slate-900">{total}</span>
        </div>
      </div>

      {total === 0 ? (
        <div className="text-center py-8 text-slate-500">
          {lang === 'hi' ? 'डैशबोर्ड दिखाने के लिए पर्याप्त डेटा नहीं है।' : 'Not enough data to show dashboard.'}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Urgent & Delayed Alerts Widget */}
          {(urgentCount > 0 || delayedCount > 0) && (
            <div className="lg:col-span-2 space-y-4">
              
              {urgentCount > 0 && (
                <div className="bg-rose-50 p-5 rounded-2xl border border-rose-200">
                  <div className="flex items-center gap-2 mb-4">
                    <AlertCircle className="w-5 h-5 text-rose-600 animate-pulse" />
                    <h4 className="text-base font-black text-rose-800">
                      {lang === 'hi' ? 'अति-महत्वपूर्ण (Urgent) लंबित शिकायतें' : 'Urgent Pending Grievances'} 
                      <span className="ml-2 bg-rose-600 text-white px-2 py-0.5 rounded-full text-xs">{urgentCount}</span>
                    </h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {urgentComplaints.map(uc => (
                      <div key={uc.id} className="bg-white p-3 rounded-xl border border-rose-100 shadow-sm">
                        <div className="flex justify-between items-start mb-1">
                          <span className="font-mono text-xs font-bold text-slate-800">{uc.complaintNumber}</span>
                          <span className="text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded font-bold">{uc.status}</span>
                        </div>
                        <div className="text-xs font-semibold text-slate-700 line-clamp-1">{uc.category}</div>
                        <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {uc.createdAt.split(',')[0]} - {uc.village}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {delayedCount > 0 && (
                <div className="bg-red-100 p-5 rounded-2xl border border-red-300">
                  <div className="flex items-center gap-2 mb-4">
                    <Clock className="w-5 h-5 text-red-600 animate-pulse" />
                    <h4 className="text-base font-black text-red-900">
                      {lang === 'hi' ? 'रेड ज़ोन (7 दिन से अधिक लंबित)' : 'Red Zone (Delayed > 7 Days)'} 
                      <span className="ml-2 bg-red-600 text-white px-2 py-0.5 rounded-full text-xs">{delayedCount}</span>
                    </h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {delayedComplaints.slice(0, 5).map(dc => (
                      <div key={dc.id} className="bg-white p-3 rounded-xl border border-red-200 shadow-sm">
                        <div className="flex justify-between items-start mb-1">
                          <span className="font-mono text-xs font-bold text-slate-800">{dc.complaintNumber}</span>
                          <span className="text-[10px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded font-bold">{dc.status}</span>
                        </div>
                        <div className="text-xs font-semibold text-slate-700 line-clamp-1">{dc.assignedDepartment}</div>
                        <div className="text-[10px] text-red-500 mt-1 font-bold flex items-center gap-1">
                          {dc.createdAt.split(',')[0]} (Overdue)
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Status Pie Chart */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
            <h4 className="text-sm font-bold text-slate-700 text-center mb-4">
              {lang === 'hi' ? 'शिकायत स्थिति (Status)' : 'Grievance Status'}
            </h4>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={
                        entry.name.includes('Resolved') || entry.name.includes('निराकृत') ? '#059669' :
                        entry.name.includes('Pending') || entry.name.includes('लंबित') ? '#d97706' :
                        '#dc2626'
                      } />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [value, lang === 'hi' ? 'शिकायतें' : 'Complaints']} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Tehsil Bar Chart */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
            <h4 className="text-sm font-bold text-slate-700 text-center mb-4">
              {lang === 'hi' ? 'तहसील वार शिकायतें' : 'Tehsil-wise Grievances'}
            </h4>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={tehsilData} layout="vertical" margin={{ top: 0, right: 20, left: 40, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#475569' }} width={80} />
                  <Tooltip cursor={{ fill: '#f1f5f9' }} />
                  <Bar dataKey="value" fill="#0f2d4e" radius={[0, 4, 4, 0]}>
                    {tehsilData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Category/Department Bar Chart */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 lg:col-span-2">
            <h4 className="text-sm font-bold text-slate-700 text-center mb-4">
              {lang === 'hi' ? 'विभाग/श्रेणी वार शिकायतें (Top 5)' : 'Top 5 Departments/Categories'}
            </h4>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryData} margin={{ top: 20, right: 30, left: 0, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 11, fill: '#475569' }} 
                    interval={0}
                    angle={-15}
                    textAnchor="end"
                  />
                  <YAxis hide />
                  <Tooltip cursor={{ fill: '#f1f5f9' }} />
                  <Bar dataKey="value" fill="#0f2d4e" radius={[4, 4, 0, 0]} barSize={40}>
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Timeline / Trend Chart */}
          {trendData.length > 0 && (
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 lg:col-span-2">
              <h4 className="text-sm font-bold text-slate-700 text-center mb-4">
                {lang === 'hi' ? 'शिकायत पंजीकरण का दैनिक ट्रेंड' : 'Daily Grievance Registration Trend'}
              </h4>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorComplaints" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0f2d4e" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#0f2d4e" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis 
                      dataKey="name" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fontSize: 12, fill: '#64748b' }} 
                      padding={{ left: 20, right: 20 }}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fontSize: 12, fill: '#64748b' }}
                      allowDecimals={false}
                    />
                    <Tooltip 
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="Complaints" 
                      stroke="#0f2d4e" 
                      strokeWidth={3}
                      fillOpacity={1} 
                      fill="url(#colorComplaints)" 
                      activeDot={{ r: 6, fill: '#0f2d4e', stroke: '#fff', strokeWidth: 2 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

        </div>
      )}
    </div>
  );
};
