import React, { useState, useEffect } from 'react';
import { 
  Send, Mic, MicOff, Paperclip, X, CheckCircle2, AlertTriangle, ShieldCheck, 
  Printer, Search, RefreshCw, Sparkles, UploadCloud, Copy, Check, FileText, 
  Phone, ArrowRight, User, MapPin, Building, Award, HelpCircle, Droplets, 
  Zap, Truck, Wheat, HeartPulse, GraduationCap, Trash2, Scale, Building2,
  Calendar, Wand2, Compass, Apple
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Complaint, Language, PriorityLevel } from '../types';
import { JHABUA_TEHSILS, COMPLAINT_CATEGORIES } from '../data/districtInfo';
import { translations } from '../translations';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { doc, writeBatch } from 'firebase/firestore';

interface ComplaintFormProps {
  onAddComplaint: (complaint: Complaint) => void;
  lang: Language;
  onTrackComplaint: (complaintNumber: string) => void;
  onOpenReceipt: (complaint: Complaint) => void;
}

// Icon mappings for categories
const CATEGORY_ICONS: Record<string, { icon: React.FC<{ className?: string }>; bg: string; color: string }> = {
  'water': { icon: Droplets, bg: 'bg-sky-50 hover:bg-sky-100 border-sky-200 text-sky-700', color: 'text-sky-600' },
  'electricity': { icon: Zap, bg: 'bg-amber-50 hover:bg-amber-100 border-amber-200 text-amber-800', color: 'text-amber-600' },
  'road': { icon: Truck, bg: 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800', color: 'text-slate-700' },
  'ration': { icon: Wheat, bg: 'bg-emerald-50 hover:bg-emerald-100 border-emerald-200 text-emerald-800', color: 'text-emerald-600' },
  'health': { icon: HeartPulse, bg: 'bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-800', color: 'text-rose-600' },
  'education': { icon: GraduationCap, bg: 'bg-blue-50 hover:bg-blue-100 border-blue-200 text-blue-800', color: 'text-blue-600' },
  'sanitation': { icon: Trash2, bg: 'bg-teal-50 hover:bg-teal-100 border-teal-200 text-teal-800', color: 'text-teal-600' },
  'revenue': { icon: Scale, bg: 'bg-purple-50 hover:bg-purple-100 border-purple-200 text-purple-800', color: 'text-purple-600' },
  'panchayat': { icon: Building2, bg: 'bg-orange-50 hover:bg-orange-100 border-orange-200 text-orange-800', color: 'text-orange-600' },
  'food_safety': { icon: Apple, bg: 'bg-red-50 hover:bg-red-100 border-red-200 text-red-800', color: 'text-red-600' },
  'agriculture': { icon: Wheat, bg: 'bg-green-50 hover:bg-green-100 border-green-200 text-green-800', color: 'text-green-600' },
  'other': { icon: HelpCircle, bg: 'bg-indigo-50 hover:bg-indigo-100 border-indigo-200 text-indigo-800', color: 'text-indigo-600' },
};

const QUICK_ISSUE_TEMPLATES = [
  {
    icon: '🚜',
    iconKey: 'agriculture',
    labelHi: 'किसान सहायता / खाद-बीज',
    labelEn: 'Farmer Help / Fertilizer-Seed',
    category: 'Agriculture & Farmer Welfare / कृषि एवं किसान कल्याण',
    promptHi: 'क्षेत्र की कृषि साख सहकारी समिति में यूरिया/डीएपी खाद उपलब्ध नहीं है। फसल बुवाई का समय निकल रहा है। कृपया खाद की उपलब्धता सुनिश्चित करें।',
    promptEn: 'Urea/DAP fertilizer is unavailable at the local cooperative society. Sowing season is passing. Please arrange fertilizer availability.',
  },
  {
    icon: '💧',
    iconKey: 'water',
    labelHi: 'हैंडपंप / पेयजल समस्या',
    labelEn: 'Water / Handpump Repair',
    category: 'Water & Handpump / नल-जल एवं हैंडपंप',
    promptHi: 'हमारे ग्राम में सार्वजनिक हैंडपंप / नल-जल योजना पिछले कई दिनों से बंद है जिससे पेयजल संकट हो रहा है। कृपया त्वरित सुधार करवाएं।',
    promptEn: 'The public handpump / drinking water scheme in our village has been out of order for several days, causing severe water distress. Please arrange prompt repair.',
  },
  {
    icon: '⚡',
    iconKey: 'electricity',
    labelHi: 'ट्रांसफार्मर / बिजली खराबी',
    labelEn: 'Burnt Power Transformer',
    category: 'Electricity / विद्युत आपूर्ति एवं ट्रांसफार्मर',
    promptHi: 'हमारे फलिया / मोहल्ले में विद्युत ट्रांसफार्मर जल गया है एवं पिछले 3 दिनों से बिजली बंद है। कृषि एवं घरेलू कार्य बाधित हैं।',
    promptEn: 'The electricity transformer in our locality has burned out and power has been off for 3 days. Farm and domestic work is halted.',
  },
  {
    icon: '🛣️',
    iconKey: 'road',
    labelHi: 'सड़क / पुलिया मरम्मत',
    labelEn: 'Damaged Road / Culvert',
    category: 'Road & PWD / सड़क एवं निर्माण',
    promptHi: 'मुख्य संपर्क मार्ग पर बड़े गड्ढे एवं जलभराव के कारण आवागमन बाधित हो गया है। दुर्घटना की आशंका बनी हुई है।',
    promptEn: 'Deep potholes and waterlogging on the main connecting road have disrupted traffic and created safety risks.',
  },
  {
    icon: '🌾',
    iconKey: 'ration',
    labelHi: 'राशन वितरण समस्या',
    labelEn: 'Ration / PDS Grievance',
    category: 'Ration & PDS / उचित मूल्य दुकान एवं राशन',
    promptHi: 'उचित मूल्य दुकान से पात्र परिवारों को निर्धारित समय एवं मात्रा में राशन सामग्री का वितरण नहीं किया जा रहा है।',
    promptEn: 'The fair price ration shop is not distributing allotted food grains to eligible families on time.',
  },
  {
    icon: '🏥',
    iconKey: 'health',
    labelHi: 'स्वास्थ्य केंद्र / डॉक्टर',
    labelEn: 'Health Center / Doctor',
    category: 'Health & Hospital / स्वास्थ्य एवं चिकित्सा',
    promptHi: 'प्राथमिक स्वास्थ्य केंद्र / उप-स्वास्थ्य केंद्र पर चिकित्सक व स्वास्थ्य कर्मी की नियमित उपस्थिति एवं आवश्यक दवाइयों की मांग है।',
    promptEn: 'Requesting regular presence of medical staff and availability of essential medicines at the local primary health center.',
  },
  {
    icon: '📑',
    iconKey: 'revenue',
    labelHi: 'राजस्व / नामांतरण / सीमांकन',
    labelEn: 'Land Mutation / Demarcation',
    category: 'Revenue & Land / राजस्व, नामांतरण व सीमांकन',
    promptHi: 'राजस्व विभाग में नामांतरण / सीमांकन / नकल हेतु आवेदन दिए जाने के बाद भी समय-सीमा में कार्य नहीं किया गया है।',
    promptEn: 'Despite submitting an application for land mutation / demarcation in the revenue office, the work has not been completed within the time limit.',
  },
  {
    icon: '🍎',
    iconKey: 'food_safety',
    labelHi: 'खाद्य सुरक्षा / मिलावट',
    labelEn: 'Food Safety / Adulteration',
    category: 'Food Safety & Adulteration / खाद्य सुरक्षा एवं मिलावट',
    promptHi: 'स्थानीय बाजार में दूषित एवं अमानक खाद्य सामग्री बेची जा रही है, जिससे स्वास्थ्य को खतरा है। कृपया जांच करें।',
    promptEn: 'Adulterated and substandard food items are being sold in the local market, posing a health risk. Please inspect.',
  },
];

export const ComplaintForm: React.FC<ComplaintFormProps> = ({
  onAddComplaint,
  lang,
  onTrackComplaint,
  onOpenReceipt,
}) => {
  const t = translations[lang];

  // Form states
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [tehsil, setTehsil] = useState('');
  const [village, setVillage] = useState('');
  const [address, setAddress] = useState('');
  const [locationCoords, setLocationCoords] = useState<{lat: number, lng: number} | null>(null);
  const [isFetchingLocation, setIsFetchingLocation] = useState(false);
  const [category, setCategory] = useState('');
  const [priority, setPriority] = useState<PriorityLevel>('Normal');
  const [description, setDescription] = useState('');
  const [attachment, setAttachment] = useState<File | null>(null);
  const [attachmentPreview, setAttachmentPreview] = useState<string | null>(null);

  // Voice dictation state
  const [isListening, setIsListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);

  // UI status
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedComplaint, setSubmittedComplaint] = useState<Complaint | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  useEffect(() => {
    const SpeechRecognition =
      (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: unknown }).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSpeechSupported(false);
    }
  }, []);

  const handleApplyTemplate = (tpl: typeof QUICK_ISSUE_TEMPLATES[0]) => {
    setCategory(tpl.category);
    setDescription(lang === 'hi' ? tpl.promptHi : tpl.promptEn);
    if (!tehsil) setTehsil('Jhabua');
    if (!village) setVillage('झाबुआ मुख्य क्षेत्र');
  };

  const handleQuickSampleFill = () => {
    setName('कमलेश डामोर');
    setMobile('9826712345');
    setTehsil('Jhabua');
    setVillage('ग्राम कल्याणपुरा (पटेल फलिया)');
    setAddress('मकान नं. 42, पंचायत भवन के पास');
    setCategory('Water & Handpump / नल-जल एवं हैंडपंप');
    setPriority('Urgent');
    setDescription(
      lang === 'hi'
        ? 'कल्याणपुरा पटेल फलिया में सार्वजनिक हैंडपंप पिछले 10 दिनों से खराब है जिससे 60 परिवारों को पीने के पानी की भारी किल्लत हो रही है। कृपया PHE विभाग से मैकेनिक भेजकर तुरंत ठीक करवाएं।'
        : 'The public handpump in Kalyanpura Patel Faliya has been defective for 10 days, causing severe water shortage for 60 households. Please dispatch PHE repair team.'
    );
  };

  const handleVoiceInput = () => {
    const SpeechRecognition =
      (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: unknown }).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert(t.voiceNotSupported);
      return;
    }

    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const recognition = new (SpeechRecognition as any)();
      recognition.lang = lang === 'hi' ? 'hi-IN' : 'en-IN';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
      };

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setDescription((prev) => (prev ? `${prev} ${transcript}` : transcript));
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setErrorMsg(lang === 'hi' ? 'फ़ाइल का आकार 5MB से कम होना चाहिए।' : 'File size must be under 5MB.');
        return;
      }
      setAttachment(file);
      if (file.type.startsWith('image/')) {
        const url = URL.createObjectURL(file);
        setAttachmentPreview(url);
      } else {
        setAttachmentPreview(null);
      }
    }
  };

  const removeAttachment = () => {
    setAttachment(null);
    setAttachmentPreview(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Basic Validation
    if (!name.trim()) {
      setErrorMsg(lang === 'hi' ? 'कृपया अपना पूरा नाम दर्ज करें।' : 'Please enter your full name.');
      return;
    }

    const cleanMobile = mobile.replace(/\D/g, '');
    if (cleanMobile.length !== 10) {
      setErrorMsg(lang === 'hi' ? 'कृपया 10 अंकों का वैध मोबाइल नंबर दर्ज करें।' : 'Please enter a valid 10-digit mobile number.');
      return;
    }

    if (!tehsil) {
      setErrorMsg(lang === 'hi' ? 'कृपया तहसील का चयन करें।' : 'Please select a Tehsil.');
      return;
    }

    if (!village.trim()) {
      setErrorMsg(lang === 'hi' ? 'कृपया ग्राम / वार्ड का नाम दर्ज करें।' : 'Please enter Gram Panchayat / Village / Ward.');
      return;
    }

    if (!category) {
      setErrorMsg(lang === 'hi' ? 'कृपया शिकायत की श्रेणी चुनें।' : 'Please select complaint category.');
      return;
    }

    if (!description.trim() || description.trim().length < 10) {
      setErrorMsg(
        lang === 'hi'
          ? 'कृपया शिकायत का पर्याप्त विवरण लिखें (कम से कम 10 अक्षर)।'
          : 'Please enter a detailed description of your grievance (at least 10 characters).'
      );
      return;
    }

    let userId = auth.currentUser?.uid;
    if (!userId) {
      let storedId = localStorage.getItem('jhabua_citizen_uid');
      if (!storedId) {
        storedId = 'cit_' + Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
        localStorage.setItem('jhabua_citizen_uid', storedId);
      }
      userId = storedId;
    }

    setIsSubmitting(true);

    const matchedCategory = COMPLAINT_CATEGORIES.find((c) => c.name === category);
    const assignedDept = matchedCategory ? matchedCategory.dept : 'Collectorate Grievance Cell (कलेक्टर जनसुनवाई प्रकोष्ठ)';

    // Generate random 4-digit ID
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const generatedNumber = `JHB-2026-${randomSuffix}`;
    const complaintId = String(Date.now()); // Using timestamp as doc ID

    const now = new Date();
    const formattedDate = now.toLocaleString('en-IN', {
      dateStyle: 'medium',
      timeStyle: 'short',
    });

    const newComplaint: Complaint = {
      id: complaintId,
      complaintNumber: generatedNumber,
      name: name.trim(),
      mobile: cleanMobile,
      email: email.trim() || undefined,
      tehsil,
      village: village.trim(),
      address: address.trim() || undefined,
      category,
      priority,
      description: description.trim(),
      attachmentName: attachment ? attachment.name : undefined,
      attachmentUrl: attachmentPreview || undefined,
      status: 'Pending',
      createdAt: formattedDate,
      assignedDepartment: assignedDept,
      assignedOfficer: 'कलेक्टर जनसुनवाई नोडल अधिकारी',
      timeline: [
        {
          title: 'Grievance Registered Successfully',
          titleHi: 'शिकायत सफलतापूर्वक पंजीकृत हुई',
          timestamp: formattedDate,
          description: `Grievance submitted via Jhabua Collector Portal and forwarded to ${assignedDept}.`,
          descriptionHi: `झाबुआ कलेक्टर पोर्टल के माध्यम से शिकायत दर्ज हुई और ${assignedDept} को प्रेषित की गई।`,
          status: 'Pending',
        },
      ],
    };

    try {
      const batch = writeBatch(db);
      
      const publicRef = doc(db, 'complaints', complaintId);
      batch.set(publicRef, {
        userId,
        complaintNumber: generatedNumber,
        category,
        tehsil,
        priority,
        status: 'Pending',
        createdAt: formattedDate,
        assignedDepartment: assignedDept,
        assignedOfficer: 'कलेक्टर जनसुनवाई नोडल अधिकारी',
        timeline: newComplaint.timeline
      });

      const privateRef = doc(db, `complaints/${complaintId}/private/info`);
      const privateData: any = {
        name: name.trim(),
        mobile: cleanMobile,
        village: village.trim(),
        description: description.trim(),
      };
      if (email.trim()) privateData.email = email.trim();
      let finalAddress = address.trim();
      if (locationCoords) {
        const geoLink = `\n[GPS: ${locationCoords.lat}, ${locationCoords.lng}]`;
        finalAddress = finalAddress ? finalAddress + geoLink : geoLink.trim();
      }
      if (finalAddress) privateData.address = finalAddress;
      if (attachment) privateData.attachmentName = attachment.name;
      if (attachmentPreview) privateData.attachmentUrl = attachmentPreview;

      batch.set(privateRef, privateData);

      await batch.commit();

      onAddComplaint(newComplaint);
      setSubmittedComplaint(newComplaint);

      // Trigger celebratory confetti
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {
        // confetti fallback
      }
    } catch (err) {
      console.error(err);
      try {
        handleFirestoreError(err, OperationType.CREATE, `complaints/${complaintId}`);
      } catch (e: any) {
        setErrorMsg(e.message || 'An error occurred while submitting.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyComplaintNo = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2500);
  };

  const handleResetForm = () => {
    setName('');
    setMobile('');
    setEmail('');
    setTehsil('');
    setVillage('');
    setAddress('');
    setLocationCoords(null);
    setCategory('');
    setPriority('Normal');
    setDescription('');
    removeAttachment();
    setSubmittedComplaint(null);
    setErrorMsg(null);
  };

  // If successfully submitted, show the official acknowledgment card
  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      alert(lang === 'hi' ? 'आपका ब्राउज़र लोकेशन सपोर्ट नहीं करता है।' : 'Geolocation is not supported by your browser.');
      return;
    }
    setIsFetchingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        setLocationCoords({ lat, lng });
        setIsFetchingLocation(false);
        // Automatically add GPS text to the address if it's empty
        if (!address) {
          setAddress(lang === 'hi' ? `[GPS लोकेशन दर्ज: ${lat.toFixed(4)}, ${lng.toFixed(4)}]` : `[GPS Location Added: ${lat.toFixed(4)}, ${lng.toFixed(4)}]`);
        }
      },
      (error) => {
        console.error("Error getting location", error.code, error.message);
        setIsFetchingLocation(false);
        
        let errorMsg = lang === 'hi' ? 'लोकेशन प्राप्त करने में त्रुटि। कृपया GPS चालू करें और ब्राउज़र में परमिशन दें (Permission Allow)।' : 'Unable to retrieve location. Please enable GPS and allow location permission in your browser.';
        
        if (error.code === 1) { // PERMISSION_DENIED
          errorMsg = lang === 'hi' ? 'लोकेशन की अनुमति नहीं दी गई। कृपया ब्राउज़र में लोकेशन परमिशन Allow करें।' : 'Location permission denied. Please allow location access in your browser.';
        }
        
        alert(errorMsg);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  if (submittedComplaint) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-10">
        <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-lg border border-emerald-200">
          <div className="flex items-center gap-4 border-b border-slate-100 pb-5">
            <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 shadow-sm">
              <CheckCircle2 className="w-10 h-10 text-emerald-600" />
            </div>
            <div>
              <span className="text-xs font-black uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 inline-block mb-1">
                ✓ {lang === 'hi' ? 'सफल पंजीकरण' : 'Successfully Registered'}
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-[#0a2540]">
                {t.successHeading}
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                {lang === 'hi'
                  ? 'आपकी शिकायत कलेक्टर जनसुनवाई प्रकोष्ठ में दर्ज हो गई है।'
                  : 'Your grievance has been lodged with Jhabua District Public Hearing Cell.'}
              </p>
            </div>
          </div>

          <div className="bg-slate-50 border-2 border-dashed border-[#0f2d4e]/30 rounded-2xl p-5 my-6">
            <div className="flex items-center justify-between">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                {t.complaintNoLabel}
              </div>
              <button
                onClick={() => handleCopyComplaintNo(submittedComplaint.complaintNumber)}
                className="inline-flex items-center gap-1 text-xs font-bold text-[#0f2d4e] hover:text-[#0a2540] bg-white px-3 py-1 rounded-lg border border-slate-200 shadow-2xs cursor-pointer active:scale-95 transition"
              >
                {copiedId ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{lang === 'hi' ? 'कॉपी हो गया' : 'Copied'}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>{lang === 'hi' ? 'कॉपी करें' : 'Copy ID'}</span>
                  </>
                )}
              </button>
            </div>
            <div className="text-3xl sm:text-4xl font-mono font-black text-[#0f2d4e] mt-1 tracking-wider">
              {submittedComplaint.complaintNumber}
            </div>
            <div className="text-xs sm:text-sm text-slate-600 mt-2 flex items-center gap-1.5 font-medium">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{t.keepSafeNotice}</span>
            </div>
          </div>

          {/* Summary Box */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 bg-slate-50 p-4 rounded-2xl text-xs sm:text-sm mb-6 border border-slate-200/80">
            <div>
              <span className="text-slate-500 font-medium">{lang === 'hi' ? 'आवेदक का नाम:' : 'Applicant:'}</span>{' '}
              <strong className="text-slate-900 font-bold">{submittedComplaint.name}</strong>
            </div>
            <div>
              <span className="text-slate-500 font-medium">{lang === 'hi' ? 'मोबाइल नंबर:' : 'Mobile:'}</span>{' '}
              <strong className="text-slate-900 font-mono font-bold">{submittedComplaint.mobile}</strong>
            </div>
            <div>
              <span className="text-slate-500 font-medium">{lang === 'hi' ? 'तहसील / ब्लॉक:' : 'Tehsil:'}</span>{' '}
              <strong className="text-slate-900 font-bold">{submittedComplaint.tehsil}</strong>
            </div>
            <div>
              <span className="text-slate-500 font-medium">{lang === 'hi' ? 'श्रेणी / विभाग:' : 'Category:'}</span>{' '}
              <strong className="text-slate-900 font-bold">{submittedComplaint.category}</strong>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              id="btn-print-receipt"
              onClick={() => onOpenReceipt(submittedComplaint)}
              className="flex-1 flex items-center justify-center gap-2 bg-[#0f2d4e] hover:bg-[#0a2540] text-white px-5 py-3.5 rounded-xl font-bold transition-all shadow-md cursor-pointer active:scale-98"
            >
              <Printer className="w-5 h-5 text-amber-300" />
              <span>{t.printSlipBtn}</span>
            </button>

            <button
              id="btn-track-now"
              onClick={() => onTrackComplaint(submittedComplaint.complaintNumber)}
              className="flex-1 flex items-center justify-center gap-2 bg-emerald-700 hover:bg-emerald-800 text-white px-5 py-3.5 rounded-xl font-bold transition-all shadow-md cursor-pointer active:scale-98"
            >
              <Search className="w-5 h-5 text-amber-300" />
              <span>{t.trackNowBtn}</span>
            </button>

            <button
              id="btn-file-another"
              onClick={handleResetForm}
              className="flex-1 flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800 px-5 py-3.5 rounded-xl font-bold transition-all border border-slate-200 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>{t.fileAnotherBtn}</span>
            </button>
          </div>

          <button
            onClick={() => {
              const message = `*जनसुनवाई शिकायत सफलतापूर्वक दर्ज*\n\n*आवेदक:* ${submittedComplaint.name}\n*शिकायत क्र:* ${submittedComplaint.complaintNumber}\n*तहसील:* ${submittedComplaint.tehsil}\n\n*पोर्टल पर अपनी शिकायत की स्थिति ट्रैक करें:* ${window.location.origin}`;
              window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
            }}
            className="w-full mt-3 flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1ebd5a] text-white px-5 py-3.5 rounded-xl font-bold transition-all shadow-md cursor-pointer active:scale-98"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.347-.272.273-1.04 1.02-1.04 2.487 0 1.467 1.064 2.885 1.213 3.083.149.198 2.094 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/>
            </svg>
            <span>{lang === 'hi' ? 'WhatsApp पर शेयर करें' : 'Share on WhatsApp'}</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full space-y-6">
      {/* Modern Hero & Quick Action Matrix */}
      <section className="bg-linear-to-r from-[#091c30] via-[#0f2d4e] to-[#064e3b] text-white py-8 sm:py-12 px-4 shadow-md rounded-b-3xl">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-extrabold px-3 py-1 rounded-full">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>{t.heroTag}</span>
              </div>
              <h2 className="text-2xl sm:text-4xl font-black tracking-tight">
                {lang === 'hi' ? 'झाबुआ जनसुनवाई एवं लोक सेवा पोर्टल' : 'Jhabua Civic Grievance & Public Hearing Portal'}
              </h2>
              <p className="text-slate-200 text-xs sm:text-sm max-w-2xl leading-relaxed">
                {t.heroSub}
              </p>

              {/* Quick Auto-Demo Fill for Easy Testing */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleQuickSampleFill}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 border border-white/20 text-amber-300 text-xs font-bold transition cursor-pointer backdrop-blur-xs"
                >
                  <Wand2 className="w-3.5 h-3.5 text-amber-300" />
                  <span>{lang === 'hi' ? '⚡ 1-क्लिक में उदाहरण फॉर्म भरें (Demo Fill)' : '⚡ 1-Click Sample Demo Fill'}</span>
                </button>
              </div>
            </div>

            {/* Quick KPI Badge */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-2xl flex items-center gap-4 shrink-0">
              <div className="w-12 h-12 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-xl shadow-md">
                ✓
              </div>
              <div>
                <div className="text-[10px] uppercase font-bold text-amber-300 tracking-wider">
                  {lang === 'hi' ? 'समय-सीमा गारंटी (SLA)' : 'Guaranteed Redressal'}
                </div>
                <div className="text-base font-extrabold text-white">
                  {lang === 'hi' ? '7 से 15 कार्यदिवस' : '7–15 Working Days'}
                </div>
                <div className="text-[11px] text-slate-300">
                  {lang === 'hi' ? 'कलेक्टर सीधी निगरानी' : 'Monitored by Collector'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Complaint Form Container */}
      <div className="max-w-5xl mx-auto px-4 -mt-6 mb-16">
        <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-lg border border-slate-200/90 space-y-6">
          {/* Steps Progress Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-200 pb-5 gap-3">
            <div>
              <h3 className="text-xl sm:text-2xl font-black text-[#0a2540]">
                {t.formTitle}
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                {t.formSubtitle}
              </p>
            </div>
            
            <div className="flex items-center gap-2 text-[11px] font-bold text-slate-700 bg-slate-100 px-3.5 py-1.5 rounded-full self-start sm:self-center border border-slate-200">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>{lang === 'hi' ? 'नागरिक अधिकार पत्रक अनुरूप' : 'Citizen Charter Compliant'}</span>
            </div>
          </div>

          {/* Quick Problem Starter Chips */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200/80">
            <div className="text-xs font-bold text-slate-700 mb-2.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>{lang === 'hi' ? 'त्वरित विषय चयन (Quick 1-Tap Topics):' : 'Quick 1-Tap Grievance Topics:'}</span>
              </span>
              <span className="text-[10px] text-slate-400 hidden sm:inline">{lang === 'hi' ? 'एक क्लिक में विषय व विवरण चुनें' : 'Click to auto-fill description'}</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {QUICK_ISSUE_TEMPLATES.map((tpl, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleApplyTemplate(tpl)}
                  className="px-3 py-2.5 rounded-xl text-xs font-semibold bg-white border border-slate-200 hover:border-[#0f2d4e] hover:bg-slate-100 text-slate-800 transition shadow-2xs cursor-pointer flex items-center gap-2 text-left active:scale-98"
                >
                  <span className="text-lg">{tpl.icon}</span>
                  <span className="truncate">{lang === 'hi' ? tpl.labelHi : tpl.labelEn}</span>
                </button>
              ))}
            </div>
          </div>

          {errorMsg && (
            <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs sm:text-sm font-semibold flex items-center gap-2.5">
              <AlertTriangle className="w-5 h-5 shrink-0 text-rose-600" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form id="complaintForm" onSubmit={handleSubmit} className="space-y-6">
            {/* Step 1: Citizen Details */}
            <div className="bg-slate-50/70 p-5 sm:p-6 rounded-2xl border border-slate-200 space-y-4">
              <div className="text-xs font-black uppercase tracking-wider text-[#0f2d4e] flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-[#0f2d4e] text-white flex items-center justify-center text-xs font-bold">1</span>
                <User className="w-4 h-4 text-[#0f2d4e]" />
                <span>{lang === 'hi' ? 'नागरिक व्यक्तिगत विवरण (Applicant Details)' : 'Citizen Information'}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Full Name */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-500" />
                    <span>{t.fullName} *</span>
                  </label>
                  <input
                    id="name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={t.fullNamePlaceholder}
                    required
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:border-[#0f2d4e] focus:ring-2 focus:ring-[#0f2d4e]/20 outline-hidden transition text-slate-900 font-medium text-sm bg-white"
                  />
                </div>

                {/* Mobile Number */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-500" />
                    <span>{t.mobile} *</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-2.5 text-xs font-bold text-slate-400">
                      +91
                    </span>
                    <input
                      id="mobile"
                      type="tel"
                      maxLength={10}
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                      placeholder={t.mobilePlaceholder}
                      required
                      className="w-full pl-12 pr-4 py-2.5 rounded-xl border border-slate-300 focus:border-[#0f2d4e] focus:ring-2 focus:ring-[#0f2d4e]/20 outline-hidden transition text-slate-900 font-medium text-sm font-mono bg-white"
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    {t.email}
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={t.emailPlaceholder}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:border-[#0f2d4e] focus:ring-2 focus:ring-[#0f2d4e]/20 outline-hidden transition text-slate-900 font-medium text-sm bg-white"
                  />
                </div>

                {/* Priority */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    {t.priority}
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setPriority('Normal')}
                      className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition cursor-pointer flex items-center justify-center gap-1.5 ${
                        priority === 'Normal'
                          ? 'bg-[#0f2d4e] text-white border-[#0f2d4e] shadow-xs'
                          : 'border-slate-300 text-slate-700 hover:bg-slate-100 bg-white'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{t.priorityNormal}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPriority('Urgent')}
                      className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition cursor-pointer flex items-center justify-center gap-1.5 ${
                        priority === 'Urgent'
                          ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                          : 'border-slate-300 text-slate-700 hover:bg-slate-100 bg-white'
                      }`}
                    >
                      <span>⚡</span>
                      <span>{t.priorityUrgent}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Step 2: Location & Visual Category Selector */}
            <div className="bg-slate-50/70 p-5 sm:p-6 rounded-2xl border border-slate-200 space-y-4">
              <div className="text-xs font-black uppercase tracking-wider text-[#0f2d4e] flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-[#0f2d4e] text-white flex items-center justify-center text-xs font-bold">2</span>
                <Compass className="w-4 h-4 text-[#0f2d4e]" />
                <span>{lang === 'hi' ? 'स्थान एवं श्रेणी चयन (Location & Category)' : 'Location & Category'}</span>
              </div>

              {/* Visual Icon Grid for Categories */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                  {lang === 'hi' ? '1-क्लिक में समस्या श्रेणी चुनें (Tap to Select):' : 'Tap an Icon to Select Category:'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
                  {COMPLAINT_CATEGORIES.map((cat) => {
                    const iconConfig = CATEGORY_ICONS[cat.id] || CATEGORY_ICONS.other;
                    const IconComp = iconConfig.icon;
                    const isSelected = category === cat.name;

                    return (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setCategory(cat.name)}
                        className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-2 active:scale-95 ${
                          isSelected
                            ? 'bg-[#0f2d4e] text-white border-[#0f2d4e] shadow-md ring-2 ring-amber-400'
                            : `${iconConfig.bg} shadow-2xs`
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                            isSelected ? 'bg-white/20 text-white' : 'bg-white shadow-2xs'
                          }`}>
                            <IconComp className={`w-4 h-4 ${isSelected ? 'text-amber-300' : iconConfig.color}`} />
                          </div>
                          {isSelected && <Check className="w-4 h-4 text-amber-300" />}
                        </div>
                        <div className="text-xs font-bold line-clamp-2 leading-tight">
                          {lang === 'hi' ? cat.nameHi : cat.nameEn}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                {/* Tehsil Selector */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-500" />
                    <span>{t.tehsil} *</span>
                  </label>
                  <select
                    id="tehsil"
                    value={tehsil}
                    onChange={(e) => setTehsil(e.target.value)}
                    required
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:border-[#0f2d4e] focus:ring-2 focus:ring-[#0f2d4e]/20 outline-hidden transition text-slate-900 font-medium text-sm bg-white"
                  >
                    <option value="">{t.selectTehsil}</option>
                    {JHABUA_TEHSILS.map((th) => (
                      <option key={th.id} value={th.name}>
                        {lang === 'hi' ? `${th.nameHi} (${th.name})` : th.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Village / Gram Panchayat */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-1">
                    <Building className="w-3.5 h-3.5 text-slate-500" />
                    <span>{t.village} *</span>
                  </label>
                  <input
                    id="village"
                    type="text"
                    value={village}
                    onChange={(e) => setVillage(e.target.value)}
                    placeholder={t.villagePlaceholder}
                    required
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:border-[#0f2d4e] focus:ring-2 focus:ring-[#0f2d4e]/20 outline-hidden transition text-slate-900 font-medium text-sm bg-white"
                  />
                </div>

                {/* Address */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
                      {t.address}
                    </label>
                    <button
                      type="button"
                      onClick={handleGetLocation}
                      disabled={isFetchingLocation || locationCoords !== null}
                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[10px] font-bold transition cursor-pointer ${
                        locationCoords 
                          ? 'bg-emerald-100 text-emerald-700 border border-emerald-300' 
                          : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200'
                      }`}
                    >
                      {locationCoords ? <Check className="w-3 h-3" /> : <MapPin className="w-3 h-3" />}
                      <span>
                        {isFetchingLocation 
                          ? (lang === 'hi' ? 'लोकेशन ढूंढ रहे...' : 'Fetching...') 
                          : locationCoords 
                            ? (lang === 'hi' ? 'GPS दर्ज' : 'GPS Captured')
                            : (lang === 'hi' ? 'मेरी लोकेशन लें (GPS)' : 'Get My Location (GPS)')}
                      </span>
                    </button>
                  </div>
                  <input
                    id="address"
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder={t.addressPlaceholder}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:border-[#0f2d4e] focus:ring-2 focus:ring-[#0f2d4e]/20 outline-hidden transition text-slate-900 font-medium text-sm bg-white"
                  />
                </div>
              </div>
            </div>

            {/* Step 3: Grievance Description & Evidence */}
            <div className="bg-slate-50/70 p-5 sm:p-6 rounded-2xl border border-slate-200 space-y-4">
              <div className="text-xs font-black uppercase tracking-wider text-[#0f2d4e] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-[#0f2d4e] text-white flex items-center justify-center text-xs font-bold">3</span>
                  <FileText className="w-4 h-4 text-[#0f2d4e]" />
                  <span>{lang === 'hi' ? 'समस्या विवरण एवं दस्तावेज (Grievance & Proof)' : 'Grievance Description'}</span>
                </div>
                
                {speechSupported && (
                  <button
                    type="button"
                    onClick={handleVoiceInput}
                    className={`inline-flex items-center gap-1 px-3.5 py-1.5 rounded-full text-xs font-bold transition cursor-pointer shadow-xs ${
                      isListening
                        ? 'bg-rose-600 text-white animate-pulse'
                        : 'bg-amber-100 text-amber-900 hover:bg-amber-200 border border-amber-300'
                    }`}
                  >
                    {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-amber-700" />}
                    <span>{isListening ? (lang === 'hi' ? 'सुन रहे हैं...' : 'Listening...') : t.voiceButton}</span>
                  </button>
                )}
              </div>

              <div>
                <textarea
                  id="description"
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={t.descriptionPlaceholder}
                  required
                  className="w-full px-4 py-3 rounded-2xl border border-slate-300 focus:border-[#0f2d4e] focus:ring-2 focus:ring-[#0f2d4e]/20 outline-hidden transition text-slate-900 font-medium text-sm bg-white leading-relaxed"
                ></textarea>
                <div className="text-right text-[10px] text-slate-400 mt-1">
                  {description.length} {lang === 'hi' ? 'अक्षर' : 'characters'}
                </div>
              </div>

              {/* Document Upload Area */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <Paperclip className="w-3.5 h-3.5 text-slate-500" />
                  <span>{t.attachment}</span>
                </label>
                <div className="border-2 border-dashed border-slate-300 hover:border-[#0f2d4e] rounded-2xl p-4 text-center bg-white transition relative">
                  <input
                    type="file"
                    onChange={handleFileChange}
                    accept="image/*,.pdf,.doc,.docx"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <div className="flex flex-col items-center justify-center gap-1.5 pointer-events-none">
                    <UploadCloud className="w-7 h-7 text-slate-400" />
                    <div className="text-xs font-bold text-slate-700">
                      {attachment ? attachment.name : t.attachmentHint}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      PNG, JPG, PDF (Max 5MB)
                    </div>
                  </div>
                </div>

                {attachmentPreview && (
                  <div className="mt-3 flex items-center gap-3 bg-white p-2.5 rounded-xl border border-slate-200">
                    <img
                      src={attachmentPreview}
                      alt="Proof"
                      className="w-12 h-12 object-cover rounded-lg border border-slate-200"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-slate-800 truncate">{attachment?.name}</div>
                      <div className="text-[10px] text-slate-400">
                        {((attachment?.size || 0) / 1024).toFixed(1)} KB
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={removeAttachment}
                      className="p-1 rounded-lg text-rose-500 hover:bg-rose-50 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Direct Form Submission Action Bar */}
            <div className="bg-slate-50/90 p-5 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2.5 text-xs text-slate-600 font-medium">
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>
                  {lang === 'hi'
                    ? 'मैं प्रमाणित करता/करती हूँ कि मेरे द्वारा दी गई उपरोक्त सभी जानकारी सत्य एवं प्रामाणिक है।'
                    : 'I declare that the information provided above is authentic and true to the best of my knowledge.'}
                </span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto relative overflow-hidden group px-8 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm transition-all shadow-xl shadow-emerald-500/30 flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-50 shrink-0 ring-2 ring-emerald-500 ring-offset-2 ring-offset-slate-50"
              >
                {/* Glowing sweeping shimmer effect */}
                <span className="absolute top-0 -inset-full h-full w-1/2 z-0 block transform -skew-x-12 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-[shimmer_2s_infinite]"></span>
                
                <div className="relative z-10 flex items-center gap-2">
                  {isSubmitting ? (
                    <RefreshCw className="w-5 h-5 animate-spin" />
                  ) : (
                    <Send className="w-5 h-5 text-amber-300 group-hover:translate-x-1 transition-transform" />
                  )}
                  <span>{isSubmitting ? (lang === 'hi' ? 'दर्ज हो रहा है...' : 'Submitting...') : t.submitBtn}</span>
                </div>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
