import React from 'react';
import { Phone, Mail, MapPin, ExternalLink, ShieldCheck, Heart } from 'lucide-react';
import { Language, ThemeMode } from '../types';
import { translations } from '../translations';

interface FooterProps {
  lang: Language;
  theme?: ThemeMode;
}

export const Footer: React.FC<FooterProps> = ({ lang, theme = 'royal' }) => {
  const t = translations[lang];

  const getFooterBg = () => {
    switch (theme) {
      case 'nature':
        return 'bg-[#022c22] border-t-4 border-[#059669]';
      case 'bhagoria':
        return 'bg-[#2b0b02] border-t-4 border-[#ea580c]';
      case 'dark':
        return 'bg-[#050811] border-t-4 border-[#f59e0b]';
      case 'royal':
      default:
        return 'bg-[#071424] border-t-4 border-[#ea580c]';
    }
  };

  return (
    <footer className={`w-full text-white pt-12 pb-8 transition-colors ${getFooterBg()}`}>
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8 mb-10 text-xs">
        {/* Col 1: District Info */}
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-linear-to-br from-amber-500 to-orange-600 text-white flex items-center justify-center font-black text-xl shadow-md border border-white/20">
              झा
            </div>
            <div>
              <div className="font-black text-sm text-amber-400">
                {lang === 'hi' ? 'जिला प्रशासन झाबुआ' : 'District Administration Jhabua'}
              </div>
              <div className="text-[11px] text-slate-400">
                {lang === 'hi' ? 'कलेक्टर जनसुनवाई निवारण प्रकोष्ठ' : 'Collectorate Grievance Portal'}
              </div>
            </div>
          </div>
          <p className="text-slate-300 leading-relaxed text-[11px]">
            {t.disclaimer}
          </p>
        </div>

        {/* Col 2: Quick Links */}
        <div className="space-y-2">
          <h4 className="text-xs font-black uppercase tracking-wider text-amber-400 mb-3">
            {lang === 'hi' ? 'महत्वपूर्ण शासकीय पोर्टल' : 'Govt Portals'}
          </h4>
          <ul className="space-y-2 text-slate-300">
            <li>
              <a
                href="http://cmhelpline.mp.gov.in"
                target="_blank"
                rel="noreferrer"
                className="hover:text-amber-300 flex items-center gap-1.5 transition"
              >
                <span>मुख्यमंत्री हेल्पलाइन (CM Helpline 181)</span>
                <ExternalLink className="w-3 h-3 text-slate-400" />
              </a>
            </li>
            <li>
              <a
                href="https://jhabua.nic.in"
                target="_blank"
                rel="noreferrer"
                className="hover:text-amber-300 flex items-center gap-1.5 transition"
              >
                <span>झाबुआ जिला आधिकारिक वेबसाइट (NIC)</span>
                <ExternalLink className="w-3 h-3 text-slate-400" />
              </a>
            </li>
            <li>
              <a
                href="https://mpedistrict.gov.in"
                target="_blank"
                rel="noreferrer"
                className="hover:text-amber-300 flex items-center gap-1.5 transition"
              >
                <span>म.प्र. ई-डिस्ट्रिक्ट लोक सेवा गारंटी</span>
                <ExternalLink className="w-3 h-3 text-slate-400" />
              </a>
            </li>
            <li>
              <a
                href="https://mponline.gov.in"
                target="_blank"
                rel="noreferrer"
                className="hover:text-amber-300 flex items-center gap-1.5 transition"
              >
                <span>एमपी ऑनलाइन नागरिक सेवाएं</span>
                <ExternalLink className="w-3 h-3 text-slate-400" />
              </a>
            </li>
          </ul>
        </div>

        {/* Col 3: Key Helplines */}
        <div className="space-y-2">
          <h4 className="text-xs font-black uppercase tracking-wider text-amber-400 mb-3">
            {lang === 'hi' ? 'आपातकालीन दूरभाष' : 'Emergency Numbers'}
          </h4>
          <div className="space-y-1.5 text-slate-300">
            <div className="flex justify-between border-b border-white/10 pb-1">
              <span>सीएम हेल्पलाइन:</span>
              <strong className="text-amber-300 font-mono">181</strong>
            </div>
            <div className="flex justify-between border-b border-white/10 pb-1">
              <span>कलेक्टर कार्यालय झाबुआ:</span>
              <strong className="text-white font-mono">07392-243202</strong>
            </div>
            <div className="flex justify-between border-b border-white/10 pb-1">
              <span>पुलिस आपातकाल:</span>
              <strong className="text-white font-mono">100 / 112</strong>
            </div>
            <div className="flex justify-between border-b border-white/10 pb-1">
              <span>संजीवनी एम्बुलेंस:</span>
              <strong className="text-white font-mono">108</strong>
            </div>
            <div className="flex justify-between">
              <span>विद्युत शिकायत:</span>
              <strong className="text-white font-mono">1912</strong>
            </div>
          </div>
        </div>

        {/* Col 4: Contact / Address */}
        <div className="space-y-2">
          <h4 className="text-xs font-black uppercase tracking-wider text-amber-400 mb-3">
            {lang === 'hi' ? 'कार्यालय पता' : 'Collectorate Address'}
          </h4>
          <div className="text-slate-300 space-y-2 text-[11px]">
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span>कलेक्टर कार्यालय, राजगढ़ रोड, झाबुआ, मध्य प्रदेश - 457661</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-mono">dmjhabua@mp.gov.in</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-mono">07392-243303 (Control Room)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright & Disclaimer Bar */}
      <div className="border-t border-white/10 pt-6 px-4 max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left text-[11px] text-slate-400">
        <div>{t.footerText}</div>
        <div className="flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>{lang === 'hi' ? 'पारदर्शी शासन • त्वरित समाधान' : 'Transparent Governance • Swift Redressal'}</span>
        </div>
      </div>
    </footer>
  );
};

