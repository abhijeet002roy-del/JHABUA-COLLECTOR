import React, { useState } from 'react';
import { 
  Phone, Mail, MapPin, Shield, AlertTriangle, PhoneCall, Search, 
  Check, ExternalLink, ShieldAlert, Activity, HeartHandshake, Zap, 
  Smile, Flame, Building2, User, Landmark, Copy, CheckCheck
} from 'lucide-react';
import { EMERGENCY_HELPLINES, KEY_OFFICIALS } from '../data/districtInfo';
import { Language } from '../types';

interface HelplineDirectoryProps {
  lang: Language;
}

const HELPLINE_ICON_MAP: Record<string, { icon: React.FC<{ className?: string }>; color: string; bg: string }> = {
  'CM Helpline': { icon: PhoneCall, color: 'text-amber-600', bg: 'bg-amber-100 text-amber-900 border-amber-300' },
  'Collectorate Control Room': { icon: Landmark, color: 'text-blue-600', bg: 'bg-blue-100 text-blue-900 border-blue-300' },
  'Police Emergency': { icon: ShieldAlert, color: 'text-rose-600', bg: 'bg-rose-100 text-rose-900 border-rose-300' },
  'Ambulance Service': { icon: Activity, color: 'text-emerald-600', bg: 'bg-emerald-100 text-emerald-900 border-emerald-300' },
  'Women Helpline': { icon: HeartHandshake, color: 'text-pink-600', bg: 'bg-pink-100 text-pink-900 border-pink-300' },
  'Kisan Call Center': { icon: PhoneCall, color: 'text-green-600', bg: 'bg-green-100 text-green-900 border-green-300' },
  'Electricity Breakdown Help': { icon: Zap, color: 'text-amber-500', bg: 'bg-amber-100 text-amber-900 border-amber-300' },
  'Child Helpline': { icon: Smile, color: 'text-sky-600', bg: 'bg-sky-100 text-sky-900 border-sky-300' },
  'Disaster Relief / Flood': { icon: AlertTriangle, color: 'text-orange-600', bg: 'bg-orange-100 text-orange-900 border-orange-300' },
};

export const HelplineDirectory: React.FC<HelplineDirectoryProps> = ({ lang }) => {
  const [filterQuery, setFilterQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'ALL' | 'EMERGENCY' | 'OFFICIALS'>('ALL');
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);

  const filteredEmergency = EMERGENCY_HELPLINES.filter((h) => {
    const q = filterQuery.toLowerCase();
    return (
      h.service.toLowerCase().includes(q) ||
      h.serviceHi.includes(q) ||
      h.number.includes(q)
    );
  });

  const filteredOfficials = KEY_OFFICIALS.filter((o) => {
    const q = filterQuery.toLowerCase();
    return (
      o.designation.toLowerCase().includes(q) ||
      o.designationHi.includes(q) ||
      o.office.toLowerCase().includes(q) ||
      o.phone.includes(q)
    );
  });

  const handleCopy = (num: string) => {
    navigator.clipboard.writeText(num);
    setCopiedNumber(num);
    setTimeout(() => setCopiedNumber(null), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6 sm:space-y-8">
      {/* Title Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200/90">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/10 text-amber-700 flex items-center justify-center shrink-0 shadow-2xs border border-amber-200">
              <PhoneCall className="w-7 h-7 text-amber-600" />
            </div>
            <div>
              <div className="text-[11px] font-black uppercase tracking-wider text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded-full inline-block mb-1 border border-amber-200">
                {lang === 'hi' ? '24x7 निःशुल्क नागरिक सहायता' : '24x7 Citizen Helpline Directory'}
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-[#0a2540]">
                {lang === 'hi' ? 'महत्वपूर्ण प्रशासनिक एवं आपातकालीन दूरभाष' : 'Emergency & Administrative Directory'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                {lang === 'hi'
                  ? 'झाबुआ जिला प्रशासन, आपातकालीन सेवाएं व प्रमुख विभागीय नोडल अधिकारियों के संपर्क नंबर।'
                  : 'Key district administration contacts, emergency helplines, and department nodal officers.'}
              </p>
            </div>
          </div>

          {/* Quick Search */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              placeholder={lang === 'hi' ? 'नंबर या सेवा खोजें (उदा. 100, 181)...' : 'Search helpline / official...'}
              className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm font-medium rounded-2xl border border-slate-300 focus:border-[#0f2d4e] focus:ring-2 focus:ring-[#0f2d4e]/20 outline-hidden bg-slate-50 focus:bg-white transition"
            />
          </div>
        </div>

        {/* Quick Filter Tabs */}
        <div className="flex items-center gap-2 mt-6 pt-5 border-t border-slate-100 flex-wrap">
          <button
            onClick={() => setActiveCategory('ALL')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
              activeCategory === 'ALL'
                ? 'bg-[#0f2d4e] text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <span>{lang === 'hi' ? 'सभी संपर्क' : 'All Contacts'}</span>
            <span className="text-[10px] opacity-80 font-mono">({filteredEmergency.length + filteredOfficials.length})</span>
          </button>

          <button
            onClick={() => setActiveCategory('EMERGENCY')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
              activeCategory === 'EMERGENCY'
                ? 'bg-rose-700 text-white shadow-xs'
                : 'bg-rose-50 text-rose-800 hover:bg-rose-100 border border-rose-200'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-rose-500" />
            <span>{lang === 'hi' ? 'आपातकालीन सेवाएं (24x7)' : '24x7 Emergency'}</span>
            <span className="text-[10px] opacity-80 font-mono">({filteredEmergency.length})</span>
          </button>

          <button
            onClick={() => setActiveCategory('OFFICIALS')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
              activeCategory === 'OFFICIALS'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
            }`}
          >
            <Building2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'hi' ? 'जिला प्रशासनिक अधिकारी' : 'District Officials'}</span>
            <span className="text-[10px] opacity-80 font-mono">({filteredOfficials.length})</span>
          </button>
        </div>
      </div>

      {/* Emergency Grid (Toll-Free / 24x7) */}
      {(activeCategory === 'ALL' || activeCategory === 'EMERGENCY') && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base sm:text-lg font-black text-[#0a2540] flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-600" />
              <span>{lang === 'hi' ? '24x7 आपातकालीन एवं त्वरित हेल्पलाइन' : '24x7 Emergency Helplines'}</span>
            </h3>
            <span className="text-xs text-slate-500 font-bold">
              {filteredEmergency.length} {lang === 'hi' ? 'सेवाएं' : 'services'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {filteredEmergency.map((item, idx) => {
              const iconConf = HELPLINE_ICON_MAP[item.service] || { icon: PhoneCall, color: 'text-slate-600', bg: 'bg-slate-100' };
              const IconComp = iconConf.icon;

              return (
                <div
                  key={idx}
                  className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm hover:border-[#0f2d4e] transition-all flex flex-col justify-between group"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${iconConf.bg}`}>
                        <IconComp className={`w-5 h-5 ${iconConf.color}`} />
                      </div>
                      {item.isTollFree && (
                        <span className="text-[10px] font-black text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full border border-emerald-200">
                          Toll-Free
                        </span>
                      )}
                    </div>

                    <div className="mt-3">
                      <h4 className="text-sm font-bold text-slate-900 group-hover:text-[#0f2d4e] transition">
                        {lang === 'hi' ? item.serviceHi : item.service}
                      </h4>
                      <div className="text-2xl font-black font-mono text-[#0f2d4e] mt-1 tracking-tight">
                        {item.number}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-1 font-medium flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>
                        <span>{item.available}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2">
                    <a
                      href={`tel:${item.number.split('/')[0].trim().replace(/\D/g, '')}`}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-[#0f2d4e] hover:bg-[#0a2540] text-white text-xs font-black transition shadow-xs cursor-pointer active:scale-98"
                    >
                      <Phone className="w-3.5 h-3.5 text-amber-300" />
                      <span>{lang === 'hi' ? 'सीधे कॉल करें' : 'Call'}</span>
                    </a>
                    <button
                      onClick={() => handleCopy(item.number)}
                      title="Copy Number"
                      className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer border border-slate-200"
                    >
                      {copiedNumber === item.number ? (
                        <CheckCheck className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Copy className="w-4 h-4 text-slate-600" />
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Key District Officials Table / Cards */}
      {(activeCategory === 'ALL' || activeCategory === 'OFFICIALS') && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base sm:text-lg font-black text-[#0a2540] flex items-center gap-2">
              <Shield className="w-5 h-5 text-[#0f2d4e]" />
              <span>{lang === 'hi' ? 'प्रमुख जिला प्रशासनिक अधिकारी एवं संपर्क' : 'Key District Administration Officials'}</span>
            </h3>
            <span className="text-xs text-slate-500 font-bold">
              {filteredOfficials.length} {lang === 'hi' ? 'अधिकारी' : 'officials'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredOfficials.map((officer, idx) => (
              <div
                key={idx}
                className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-3.5 hover:border-slate-300 transition"
              >
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-slate-100 text-[#0f2d4e] flex items-center justify-center shrink-0 border border-slate-200">
                    <User className="w-5 h-5 text-[#0f2d4e]" />
                  </div>
                  <div>
                    <h4 className="text-sm sm:text-base font-black text-[#0f2d4e]">
                      {lang === 'hi' ? officer.designationHi : officer.designation}
                    </h4>
                    <p className="text-xs text-slate-600 font-semibold">{officer.office}</p>
                  </div>
                </div>

                <div className="space-y-2 text-xs text-slate-700 pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-200/60">
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-[#0f2d4e]" />
                      <span className="font-mono font-bold text-slate-900">{officer.phone}</span>
                    </div>
                    <a
                      href={`tel:${officer.phone}`}
                      className="px-3 py-1 rounded-lg bg-[#0f2d4e] text-white font-bold text-[11px] hover:bg-[#0a2540] transition"
                    >
                      {lang === 'hi' ? 'कॉल' : 'Call'}
                    </a>
                  </div>

                  <div className="flex items-center gap-2 px-1">
                    <Mail className="w-3.5 h-3.5 text-[#0f2d4e] shrink-0" />
                    <a
                      href={`mailto:${officer.email}`}
                      className="text-slate-600 hover:text-slate-900 font-mono underline"
                    >
                      {officer.email}
                    </a>
                  </div>

                  <div className="flex items-start gap-2 px-1">
                    <MapPin className="w-3.5 h-3.5 text-[#0f2d4e] shrink-0 mt-0.5" />
                    <span className="text-slate-600">{officer.address}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
