import React, { useState, useEffect } from 'react';
import { Phone, Shield, FileText, Search, BarChart3, BookOpen, UserCheck, CheckCircle2, Clock, Palette, Sparkles, Moon, Trees, Landmark, Flame, Volume2, VolumeX, Bell, ChevronRight, Calendar, QrCode, X } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { Language, ThemeMode } from '../types';
import { translations } from '../translations';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  lang: Language;
  setLang: (lang: Language) => void;
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  totalComplaintsCount: number;
  isAdmin?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  lang,
  setLang,
  theme,
  setTheme,
  totalComplaintsCount,
  isAdmin = false,
}) => {
  const t = translations[lang];
  const [tickerIndex, setTickerIndex] = useState(0);
  const [showQR, setShowQR] = useState(false);

  const ANNOUNCEMENTS = [
    {
      hi: '📢 जनसुनवाई सूचना: प्रत्येक मंगलवार प्रातः 11:00 बजे जिला कलेक्टर सभागृह में आमजन की समस्याएं सुनी जाती हैं।',
      en: '📢 Public Notice: Public Grievance Hearing held every Tuesday at 11:00 AM at District Collectorate Auditorium.',
    },
    {
      hi: '⚡ विद्युत समस्या निवारण: ग्रामीण क्षेत्रों में जले ट्रांसफार्मर 72 घंटे में बदलने हेतु विशेष दल तैनात।',
      en: '⚡ Power Helpline: Dedicated field teams deployed for rapid transformer replacements within 72 hours.',
    },
    {
      hi: '💧 नल-जल एवं हैंडपंप संधारण अभियान: ग्रीष्मकालीन पेयजल सुरक्षा हेतु कंट्रोल रूम दूरभाष: 07392-243303',
      en: '💧 Water Security Drive: 24x7 control room for drinking water & handpump repairs: 07392-243303',
    },
    {
      hi: '🌾 सीएम हेल्पलाइन 181: किसी भी शासकीय योजना की जानकारी एवं समाधान हेतु निःशुल्क डायल करें।',
      en: '🌾 CM Helpline 181: Dial toll-free for all MP government welfare schemes & redressals.',
    },
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setTickerIndex((prev) => (prev + 1) % ANNOUNCEMENTS.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [ANNOUNCEMENTS.length]);

  // Theme theme-specific visual headers
  const getThemeHeaderStyles = () => {
    switch (theme) {
      case 'nature':
        return {
          topBg: 'bg-[#022c22] border-[#064e3b]',
          emblemGradient: 'from-[#064e3b] via-[#047857] to-[#059669]',
          activeNav: 'bg-[#064e3b] text-white shadow-xs ring-1 ring-[#064e3b]',
          brandText: 'text-[#064e3b]',
          navBg: 'bg-[#f8faf9] border-emerald-900/10',
          announcementBg: 'bg-emerald-950/90 text-emerald-100 border-emerald-800',
        };
      case 'bhagoria':
        return {
          topBg: 'bg-[#431407] border-[#7c2d12]',
          emblemGradient: 'from-[#c2410c] via-[#ea580c] to-[#d97706]',
          activeNav: 'bg-[#c2410c] text-white shadow-xs ring-1 ring-[#c2410c]',
          brandText: 'text-[#c2410c]',
          navBg: 'bg-[#fffbf7] border-orange-900/10',
          announcementBg: 'bg-amber-950/90 text-amber-100 border-amber-800',
        };
      case 'dark':
        return {
          topBg: 'bg-[#060a14] border-[#1e293b]',
          emblemGradient: 'from-[#1e293b] via-[#334155] to-[#f59e0b]',
          activeNav: 'bg-[#f59e0b] text-slate-950 font-black shadow-xs ring-1 ring-[#f59e0b]',
          brandText: 'text-[#f8fafc]',
          navBg: 'bg-[#0f172a] border-slate-800',
          announcementBg: 'bg-slate-900 text-amber-200 border-slate-800',
        };
      case 'royal':
      default:
        return {
          topBg: 'bg-[#091c30] border-[#132c4d]',
          emblemGradient: 'from-[#0f2d4e] via-[#123c69] to-[#0a664c]',
          activeNav: 'bg-[#0f2d4e] text-white shadow-xs ring-1 ring-[#0f2d4e]',
          brandText: 'text-[#0a2540]',
          navBg: 'bg-slate-50/95 border-slate-200/90',
          announcementBg: 'bg-[#081b30] text-amber-100 border-[#153457]',
        };
    }
  };

  const themeStyles = getThemeHeaderStyles();

  return (
    <header className={`w-full sticky top-0 z-40 shadow-sm transition-colors duration-200 ${
      theme === 'dark' ? 'bg-[#0f172a] border-b border-slate-800' : 'bg-white border-b border-slate-200/90'
    }`}>
      {/* Tricolor Government Identity Accent Line */}
      <div className="h-1.5 w-full grid grid-cols-3">
        <div className="bg-[#FF9933]"></div>
        <div className="bg-white"></div>
        <div className="bg-[#138808]"></div>
      </div>

      {/* Top Banner with Emergency Numbers, Theme Switcher & Language Toggle */}
      <div className={`${themeStyles.topBg} text-white text-xs py-2 px-3 sm:px-4 border-b transition-colors`}>
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2 font-medium tracking-wide">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="text-slate-200 font-semibold text-[11px] sm:text-xs">{t.topbar}</span>
          </div>

          <div className="flex items-center gap-2 sm:gap-4 flex-wrap">
            {isAdmin && (
              <div className="bg-amber-500/20 text-amber-200 border border-amber-500/30 px-2 py-0.5 rounded-md text-[10px] font-bold flex items-center gap-1">
                <Shield className="w-3 h-3" />
                ADMIN
              </div>
            )}
            
            {/* Theme Selector Palette */}
            <div className="flex items-center gap-1 bg-black/40 backdrop-blur-xs p-1 rounded-xl border border-white/10">
              <button
                title="राजप्रशासन (Royal Malwa Theme)"
                onClick={() => setTheme('royal')}
                className={`px-2 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 transition cursor-pointer ${
                  theme === 'royal'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <Landmark className="w-3 h-3" />
                <span className="hidden sm:inline">राजप्रशासन</span>
              </button>

              <button
                title="झाबुआ प्रकृति (Forest Nature Theme)"
                onClick={() => setTheme('nature')}
                className={`px-2 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 transition cursor-pointer ${
                  theme === 'nature'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <Trees className="w-3 h-3" />
                <span className="hidden sm:inline">प्रकृति</span>
              </button>

              <button
                title="भगोरिया (Tribal Ochre Theme)"
                onClick={() => setTheme('bhagoria')}
                className={`px-2 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 transition cursor-pointer ${
                  theme === 'bhagoria'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <Flame className="w-3 h-3" />
                <span className="hidden sm:inline">भगोरिया</span>
              </button>

              <button
                title="रात्रि मोड (Dark High-Contrast Theme)"
                onClick={() => setTheme('dark')}
                className={`px-2 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 transition cursor-pointer ${
                  theme === 'dark'
                    ? 'bg-amber-400 text-slate-950 font-black shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <Moon className="w-3 h-3" />
                <span className="hidden sm:inline">डार्क</span>
              </button>
            </div>

            {/* Quick emergency chips */}
            <a 
              href="tel:181" 
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-300 hover:bg-amber-500/30 transition font-bold text-[11px]"
            >
              <Phone className="w-3 h-3 text-amber-300" />
              <span>CM Helpline 181</span>
            </a>

            {/* Language Switcher */}
            <div className="flex items-center bg-black/40 rounded-lg p-0.5 border border-white/15">
              <button
                id="lang-btn-hi"
                onClick={() => setLang('hi')}
                className={`px-2.5 py-1 rounded-md text-xs font-bold transition-all cursor-pointer ${
                  lang === 'hi'
                    ? 'bg-amber-400 text-slate-950 shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                हिन्दी
              </button>
              <button
                id="lang-btn-en"
                onClick={() => setLang('en')}
                className={`px-2.5 py-1 rounded-md text-xs font-bold transition-all cursor-pointer ${
                  lang === 'en'
                    ? 'bg-amber-400 text-slate-950 shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                English
              </button>
            </div>
            
            {/* QR Code Trigger */}
            <button
              onClick={() => setShowQR(true)}
              title={lang === 'hi' ? 'पोर्टल का QR कोड' : 'Portal QR Code'}
              className="p-1 rounded-lg bg-black/40 text-amber-300 hover:text-white hover:bg-white/10 border border-white/10 transition cursor-pointer flex items-center justify-center"
            >
              <QrCode className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* QR Code Modal */}
      {showQR && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-sm w-full shadow-2xl relative border border-slate-200 text-center animate-in zoom-in-95 duration-200">
            <button 
              onClick={() => setShowQR(false)}
              className="absolute top-4 right-4 p-2 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-full transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="mx-auto w-16 h-16 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mb-4">
              <QrCode className="w-8 h-8" />
            </div>
            
            <h3 className="text-xl font-black text-[#0f2d4e] mb-1">
              {lang === 'hi' ? 'जनसुनवाई पोर्टल' : 'Jansunwai Portal'}
            </h3>
            <p className="text-sm font-medium text-slate-500 mb-6">
              {lang === 'hi' ? 'स्कैन करके मोबाइल पर खोलें' : 'Scan to open on mobile'}
            </p>
            
            <div className="bg-slate-50 p-6 rounded-2xl border-2 border-dashed border-slate-200 flex justify-center">
              <QRCodeSVG 
                value={window.location.origin} 
                size={200}
                level="H"
                includeMargin={false}
                fgColor="#0f2d4e"
              />
            </div>
            
            <button 
              onClick={() => {
                const canvas = document.querySelector('svg');
                if (canvas) {
                  const svgData = new XMLSerializer().serializeToString(canvas);
                  const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'jhabua-jansunwai-qr.svg';
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                }
              }}
              className="mt-6 w-full py-3 bg-[#0f2d4e] hover:bg-[#0a1e35] text-white font-bold rounded-xl transition cursor-pointer"
            >
              {lang === 'hi' ? 'QR कोड डाउनलोड करें' : 'Download QR Code'}
            </button>
          </div>
        </div>
      )}

      {/* Main Branding Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-3.5 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3.5 sm:gap-4 w-full md:w-auto">
          {/* Official Emblem Shield */}
          <div className="relative shrink-0">
            <div className={`w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-linear-to-br ${themeStyles.emblemGradient} text-white flex flex-col items-center justify-center font-bold shadow-md border-2 border-amber-400 ring-2 ring-slate-200/50`}>
              <span className="text-2xl sm:text-3xl leading-none font-black text-amber-300">झा</span>
              <span className="text-[8px] uppercase tracking-widest text-slate-200 mt-0.5">JHB</span>
            </div>
            <div className="absolute -bottom-1 -right-1 bg-emerald-600 text-white text-[9px] font-black rounded-full px-1.5 py-0.2 border border-white shadow-xs">
              MP
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="inline-flex items-center gap-1 text-[10px] sm:text-[11px] font-extrabold tracking-wider uppercase text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200/80">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                {lang === 'hi' ? 'मध्य प्रदेश शासन' : 'Govt. of Madhya Pradesh'}
              </span>
              <span className={`text-[11px] font-medium hidden sm:inline ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>
                • {lang === 'hi' ? 'कलेक्टर कार्यालय, जिला झाबुआ' : 'District Collectorate Jhabua'}
              </span>
            </div>
            <h1 className={`text-xl sm:text-2xl font-black tracking-tight mt-0.5 flex items-center gap-2 ${
              theme === 'dark' ? 'text-white' : themeStyles.brandText
            }`}>
              <span>{t.portalTitle}</span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border hidden md:inline ${
                theme === 'dark' ? 'bg-slate-800 text-amber-300 border-slate-700' : 'bg-slate-100 text-slate-600 border-slate-200'
              }`}>
                24x7 Jansunwai Hub
              </span>
            </h1>
            <p className={`text-xs font-medium line-clamp-1 ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>
              {t.portalSub}
            </p>
          </div>
        </div>

        {/* Quick Highlights */}
        <div className="hidden lg:flex items-center gap-3">
          <div className={`border rounded-xl px-3.5 py-2 text-right ${
            theme === 'dark' ? 'bg-slate-800/80 border-slate-700' : 'bg-slate-50/90 border-slate-200'
          }`}>
            <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{lang === 'hi' ? 'आपातकालीन पुलिस' : 'Police'}</div>
            <div className={`text-sm font-bold font-mono ${theme === 'dark' ? 'text-slate-100' : 'text-slate-800'}`}>100 / 112</div>
          </div>
          <div className={`border rounded-xl px-3.5 py-2 text-right ${
            theme === 'dark' ? 'bg-emerald-950/40 border-emerald-800/60' : 'bg-emerald-50/80 border-emerald-200/80'
          }`}>
            <div className="text-[10px] text-emerald-500 font-bold uppercase tracking-wider">{lang === 'hi' ? 'एम्बुलेंस' : 'Ambulance'}</div>
            <div className="text-sm font-bold text-emerald-400 font-mono">108</div>
          </div>
          <div className={`border rounded-xl px-3.5 py-2 text-right ${
            theme === 'dark' ? 'bg-amber-950/40 border-amber-800/60' : 'bg-amber-50/80 border-amber-200/80'
          }`}>
            <div className="text-[10px] text-amber-500 font-bold uppercase tracking-wider">{lang === 'hi' ? 'कुल दर्ज प्रकरण' : 'Grievances'}</div>
            <div className="text-sm font-bold text-amber-500 font-mono">{totalComplaintsCount}</div>
          </div>
        </div>
      </div>

      {/* Live Announcement Marquee Bar */}
      <div className={`${themeStyles.announcementBg} border-y px-4 py-1.5 text-xs flex items-center gap-2.5 transition-colors overflow-hidden`}>
        <div className="flex items-center gap-1.5 shrink-0 font-bold text-amber-400">
          <Bell className="w-3.5 h-3.5 animate-bounce text-amber-400" />
          <span className="uppercase text-[10px] tracking-wider hidden sm:inline">{lang === 'hi' ? 'ताज़ा सूचना:' : 'Bulletin:'}</span>
        </div>
        <div className="flex-1 truncate text-[11px] sm:text-xs font-medium">
          {lang === 'hi' ? ANNOUNCEMENTS[tickerIndex].hi : ANNOUNCEMENTS[tickerIndex].en}
        </div>
        <div className="flex items-center gap-1 text-[10px] text-slate-400 shrink-0">
          <Calendar className="w-3 h-3 text-slate-400" />
          <span>{new Date().toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
        </div>
      </div>

      {/* Navigation Tabs Bar - Hidden on mobile, shown on md+ */}
      <nav className={`hidden md:block ${themeStyles.navBg} border-t px-4 transition-colors`}>
        <div className="max-w-7xl mx-auto flex items-center overflow-x-auto no-scrollbar gap-1.5 sm:gap-2.5 py-2">
          <button
            id="tab-file-complaint"
            onClick={() => setActiveTab('file')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'file'
                ? themeStyles.activeNav
                : theme === 'dark'
                ? 'text-slate-300 hover:bg-slate-800 hover:text-white'
                : 'text-slate-700 hover:bg-slate-200/70 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4 text-amber-400" />
            <span>{t.tabFileComplaint}</span>
          </button>

          <button
            id="tab-track-status"
            onClick={() => setActiveTab('track')}
            className={`relative flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'track'
                ? themeStyles.activeNav + ' ring-4 ring-sky-500/30'
                : theme === 'dark'
                ? 'text-slate-300 hover:bg-slate-800 hover:text-white'
                : 'text-slate-700 hover:bg-slate-200/70 hover:text-slate-900'
            }`}
          >
            <div className="absolute -top-1.5 -right-1.5 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500 border border-white"></span>
            </div>
            <Search className="w-4 h-4 text-sky-400" />
            <span>{t.tabTrackStatus}</span>
          </button>

          <button
            id="tab-public-stats"
            onClick={() => setActiveTab('stats')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'stats'
                ? themeStyles.activeNav
                : theme === 'dark'
                ? 'text-slate-300 hover:bg-slate-800 hover:text-white'
                : 'text-slate-700 hover:bg-slate-200/70 hover:text-slate-900'
            }`}
          >
            <BarChart3 className="w-4 h-4 text-emerald-400" />
            <span>{t.tabPublicStats}</span>
          </button>

          <button
            id="tab-directory"
            onClick={() => setActiveTab('directory')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'directory'
                ? themeStyles.activeNav
                : theme === 'dark'
                ? 'text-slate-300 hover:bg-slate-800 hover:text-white'
                : 'text-slate-700 hover:bg-slate-200/70 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-4 h-4 text-indigo-400" />
            <span>{t.tabHelplineDirectory}</span>
          </button>

          <button
            id="tab-officer-desk"
            onClick={() => setActiveTab('officer')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ml-auto cursor-pointer ${
              activeTab === 'officer'
                ? 'bg-emerald-700 text-white shadow-xs ring-1 ring-emerald-600 font-bold'
                : theme === 'dark'
                ? 'text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-700/60'
                : 'text-emerald-900 bg-emerald-100/90 hover:bg-emerald-200/90 border border-emerald-300/80 font-bold'
            }`}
          >
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <span>{t.tabOfficerDesk}</span>
          </button>
        </div>
      </nav>
    </header>
  );
};
