import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, onSnapshot, orderBy, doc, getDoc, writeBatch } from 'firebase/firestore';
import { FileText, Search, BarChart3, BookOpen, UserCheck } from 'lucide-react';
import { Header } from './components/Header';
import { ComplaintForm } from './components/ComplaintForm';
import { StatusTracker } from './components/StatusTracker';
import { PublicStats } from './components/PublicStats';
import { HelplineDirectory } from './components/HelplineDirectory';
import { OfficerDesk } from './components/OfficerDesk';
import { ReceiptModal } from './components/ReceiptModal';
import { Footer } from './components/Footer';
import { Complaint, Language, ThemeMode } from './types';
import { auth, db } from './firebase';
import { useAuth } from './hooks/useAuth';
import { INITIAL_COMPLAINTS } from './data/initialComplaints';
import { translations } from './translations';

export default function App() {
  const { user, isAdmin, loading } = useAuth();
  const [lang, setLang] = useState<Language>('hi');
  const [activeTab, setActiveTab] = useState<string>('file');
  const [theme, setTheme] = useState<ThemeMode>(() => {
    try {
      const saved = localStorage.getItem('jhabua_theme') as ThemeMode;
      if (saved && ['royal', 'nature', 'bhagoria', 'dark'].includes(saved)) {
        return saved;
      }
    } catch {
      // fallback
    }
    return 'royal';
  });

  // Apply theme to document element
  useEffect(() => {
    try {
      document.documentElement.setAttribute('data-theme', theme);
      localStorage.setItem('jhabua_theme', theme);
    } catch {
      // ignore
    }
  }, [theme]);

  // Load complaints from Firebase
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [fetchingData, setFetchingData] = useState(false);

  useEffect(() => {
    const effectiveUid = user?.uid || localStorage.getItem('jhabua_citizen_uid');
    if (!isAdmin && !effectiveUid) return;

    setFetchingData(true);

    const q = isAdmin 
      ? collection(db, 'complaints') 
      : query(collection(db, 'complaints'), where('userId', '==', effectiveUid));

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      try {
        const publicDocs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        
        // Fetch private info for each complaint
        const fullComplaintsPromises = publicDocs.map(async (pubDoc: any) => {
          let privateData: any = {};
          try {
            // Only owner and admin can read private info.
            const infoDocRef = doc(db, `complaints/${pubDoc.id}/private/info`);
            const infoDoc = await getDoc(infoDocRef);
            if (infoDoc.exists()) {
              privateData = infoDoc.data();
            }
          } catch (e) {
            console.error("Failed to fetch private data for", pubDoc.id);
          }

          return {
            id: pubDoc.id,
            complaintNumber: pubDoc.complaintNumber,
            name: privateData.name || 'Hidden',
            mobile: privateData.mobile || 'Hidden',
            email: privateData.email,
            tehsil: pubDoc.tehsil,
            village: privateData.village || pubDoc.tehsil,
            address: privateData.address,
            category: pubDoc.category,
            priority: pubDoc.priority,
            description: privateData.description || 'Description hidden for privacy.',
            attachmentName: privateData.attachmentName,
            attachmentUrl: privateData.attachmentUrl,
            status: pubDoc.status,
            createdAt: pubDoc.createdAt,
            resolvedAt: pubDoc.resolvedAt,
            assignedDepartment: pubDoc.assignedDepartment,
            assignedOfficer: pubDoc.assignedOfficer,
            officerRemark: pubDoc.officerRemark,
            timeline: pubDoc.timeline || [],
          } as Complaint;
        });

        const fullData = await Promise.all(fullComplaintsPromises);
        
        // Sort by id descending (assuming timestamp based ID)
        fullData.sort((a, b) => Number(b.id) - Number(a.id));
        setComplaints(fullData);
      } catch (err) {
        console.error("Error processing snapshot", err);
      } finally {
        setFetchingData(false);
      }
    }, (err) => {
      console.error("Listen failed", err);
      setFetchingData(false);
    });

    return () => unsubscribe();
  }, [user, isAdmin]);

  // One-time seeding of initial data if database is empty
  useEffect(() => {
    if (isAdmin && user && complaints.length === 0 && !fetchingData) {
      const seedDatabase = async () => {
        const seeded = localStorage.getItem('jhabua_db_seeded');
        if (seeded) return; // Prevent multiple seed attempts

        try {
          const snap = await getDocs(collection(db, 'complaints'));
          if (snap.empty) {
            console.log("Database is empty. Seeding initial records...");
            const batch = writeBatch(db);
            
            INITIAL_COMPLAINTS.forEach((c, index) => {
              // Creating a timestamp-like ID for consistent sorting
              const newId = Date.now().toString() + index.toString();
              const publicRef = doc(db, 'complaints', newId);
              const privateRef = doc(db, `complaints/${newId}/private/info`);
              
              batch.set(publicRef, {
                userId: user.uid,
                complaintNumber: c.complaintNumber,
                category: c.category,
                tehsil: c.tehsil,
                priority: c.priority,
                status: c.status,
                createdAt: c.createdAt,
                assignedDepartment: c.assignedDepartment || 'N/A',
                assignedOfficer: c.assignedOfficer || 'N/A',
                officerRemark: c.officerRemark || '',
                timeline: c.timeline || [],
                ...(c.resolvedAt ? { resolvedAt: c.resolvedAt } : {})
              });

              batch.set(privateRef, {
                name: c.name,
                mobile: c.mobile,
                email: c.email || '',
                address: c.address || '',
                village: c.village || '',
                description: c.description || ''
              });
            });

            await batch.commit();
            localStorage.setItem('jhabua_db_seeded', 'true');
            console.log("Seeding complete!");
          } else {
             // If there's already data but we just didn't get it locally yet
             localStorage.setItem('jhabua_db_seeded', 'true');
          }
        } catch (e) {
          console.error("Failed to seed database:", e);
        }
      };

      seedDatabase();
    }
  }, [isAdmin, user, complaints.length, fetchingData]);

  // Receipt Modal state
  const [receiptComplaint, setReceiptComplaint] = useState<Complaint | null>(null);

  // Track initial query when transitioning from filing
  const [trackQuery, setTrackQuery] = useState<string>('');

  const handleAddComplaint = (newComplaint: Complaint) => {
    // The snapshot listener will automatically update the UI.
    // We just handle local transition logic here.
  };

  const handleUpdateComplaint = (updatedComplaint: Complaint) => {
    // Similarly, OfficerDesk will mutate Firebase directly, and the snapshot listener will reflect changes.
  };

  const handleTrackFromSubmission = (complaintNumber: string) => {
    setTrackQuery(complaintNumber);
    setActiveTab('track');
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center font-bold text-slate-500">Loading App...</div>;
  }

  return (
    <div
      data-theme={theme}
      className={`min-h-screen flex flex-col font-sans selection:bg-amber-400 selection:text-slate-950 transition-colors duration-200 ${
        theme === 'dark' ? 'bg-[#0b1120] text-slate-100' : 'bg-[#f4f6fa] text-slate-900'
      }`}
    >
      <Header
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          if (tab !== 'track') {
            setTrackQuery('');
          }
        }}
        lang={lang}
        setLang={setLang}
        theme={theme}
        setTheme={setTheme}
        totalComplaintsCount={complaints.length}
        isAdmin={isAdmin}
      />

      <main className="flex-1 w-full pb-24 md:pb-12">
        {activeTab === 'file' && (
          <ComplaintForm
            onAddComplaint={handleAddComplaint}
            lang={lang}
            onTrackComplaint={handleTrackFromSubmission}
            onOpenReceipt={(c) => setReceiptComplaint(c)}
          />
        )}

        {activeTab === 'track' && (
          <StatusTracker
            complaints={complaints}
            lang={lang}
            initialQuery={trackQuery}
            onOpenReceipt={(c) => setReceiptComplaint(c)}
          />
        )}

        {activeTab === 'stats' && (
          <PublicStats
            complaints={complaints}
            lang={lang}
            isAdmin={isAdmin}
          />
        )}

        {activeTab === 'directory' && (
          <HelplineDirectory
            lang={lang}
          />
        )}

        {activeTab === 'officer' && (
          <OfficerDesk
            complaints={complaints}
            onUpdateComplaint={handleUpdateComplaint}
            lang={lang}
            isAdmin={isAdmin}
          />
        )}
      </main>

      {receiptComplaint && (
        <ReceiptModal
          complaint={receiptComplaint}
          onClose={() => setReceiptComplaint(null)}
          lang={lang}
        />
      )}

      {/* Mobile Bottom Navigation (Visible only on small screens) */}
      <div className={`md:hidden fixed bottom-0 left-0 right-0 border-t flex justify-around items-center px-1 py-2 z-50 pb-safe shadow-[0_-4px_10px_rgba(0,0,0,0.05)] ${theme === 'dark' ? 'bg-[#0f172a] border-slate-800' : 'bg-white border-slate-200'}`}>
        <button
          onClick={() => { setActiveTab('file'); setTrackQuery(''); }}
          className={`flex flex-col items-center justify-center w-1/5 rounded-lg p-1 transition-all ${activeTab === 'file' ? 'text-[#0f2d4e] dark:text-amber-400 scale-110' : 'text-slate-500 dark:text-slate-400'}`}
        >
          <FileText className={`w-5 h-5 mb-1 ${activeTab === 'file' ? 'text-amber-500 dark:text-amber-400' : ''}`} />
          <span className="text-[9px] font-bold text-center leading-tight truncate w-full">{lang === 'hi' ? 'शिकायत' : 'File'}</span>
        </button>
        <button
          onClick={() => setActiveTab('track')}
          className={`flex flex-col items-center justify-center w-1/5 rounded-lg p-1 transition-all ${activeTab === 'track' ? 'text-[#0f2d4e] dark:text-amber-400 scale-110' : 'text-slate-500 dark:text-slate-400'}`}
        >
          <Search className={`w-5 h-5 mb-1 ${activeTab === 'track' ? 'text-sky-500 dark:text-sky-400' : ''}`} />
          <span className="text-[9px] font-bold text-center leading-tight truncate w-full">{lang === 'hi' ? 'स्थिति' : 'Track'}</span>
        </button>
        <button
          onClick={() => setActiveTab('stats')}
          className={`flex flex-col items-center justify-center w-1/5 rounded-lg p-1 transition-all ${activeTab === 'stats' ? 'text-[#0f2d4e] dark:text-amber-400 scale-110' : 'text-slate-500 dark:text-slate-400'}`}
        >
          <BarChart3 className={`w-5 h-5 mb-1 ${activeTab === 'stats' ? 'text-emerald-500 dark:text-emerald-400' : ''}`} />
          <span className="text-[9px] font-bold text-center leading-tight truncate w-full">{lang === 'hi' ? 'आंकड़े' : 'Stats'}</span>
        </button>
        <button
          onClick={() => setActiveTab('directory')}
          className={`flex flex-col items-center justify-center w-1/5 rounded-lg p-1 transition-all ${activeTab === 'directory' ? 'text-[#0f2d4e] dark:text-amber-400 scale-110' : 'text-slate-500 dark:text-slate-400'}`}
        >
          <BookOpen className={`w-5 h-5 mb-1 ${activeTab === 'directory' ? 'text-indigo-500 dark:text-indigo-400' : ''}`} />
          <span className="text-[9px] font-bold text-center leading-tight truncate w-full">{lang === 'hi' ? 'संपर्क' : 'Call'}</span>
        </button>
        <button
          onClick={() => setActiveTab('officer')}
          className={`flex flex-col items-center justify-center w-1/5 rounded-lg p-1 transition-all ${activeTab === 'officer' ? 'text-[#0f2d4e] dark:text-amber-400 scale-110' : 'text-slate-500 dark:text-slate-400'}`}
        >
          <UserCheck className={`w-5 h-5 mb-1 ${activeTab === 'officer' ? 'text-emerald-600 dark:text-emerald-500' : ''}`} />
          <span className="text-[9px] font-bold text-center leading-tight truncate w-full">{lang === 'hi' ? 'अधिकारी' : 'Admin'}</span>
        </button>
      </div>

      <Footer lang={lang} theme={theme} />
    </div>
  );
}

