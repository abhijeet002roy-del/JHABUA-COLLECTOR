export type ComplaintStatus = 'Pending' | 'Under Review' | 'In Progress' | 'Resolved' | 'Rejected';

export type PriorityLevel = 'Normal' | 'Urgent';

export interface Complaint {
  id: string;
  complaintNumber: string;
  name: string;
  mobile: string;
  email?: string;
  tehsil: string;
  village: string;
  address?: string;
  category: string;
  priority: PriorityLevel;
  description: string;
  status: ComplaintStatus;
  createdAt: string;
  assignedDepartment?: string;
  assignedOfficer?: string;
  officerRemark?: string;
  resolvedAt?: string;
  attachmentName?: string;
  attachmentUrl?: string;
  timeline: {
    title: string;
    titleHi: string;
    timestamp: string;
    description: string;
    descriptionHi: string;
    status: ComplaintStatus;
  }[];
}

export type Language = 'hi' | 'en';

export type ThemeMode = 'royal' | 'nature' | 'bhagoria' | 'dark';
