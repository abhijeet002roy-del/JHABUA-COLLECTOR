# Firebase Security Specification

## Data Invariants
1. Complaints can be created by any authenticated user (including anonymous).
2. Complaints must have an unguessable complaint ID (or UUID) to prevent scraping.
3. Only the owner or an admin can read the public complaint details (`complaints/{complaintId}`).
4. Only the owner or an admin can read the private complaint PII (`complaints/{complaintId}/private/info`).
5. Only an admin can update the `complaints/{complaintId}` document (e.g., to change status, assign officers, add remarks).
6. Admins are users who have a document in the `admins` collection matching their `uid` or `email`. Wait, `uid` is safer. Let's use `admins/{uid}`.
7. `status` transitions are strictly controlled (e.g. users cannot bypass to "Resolved").

## "Dirty Dozen" Payloads
1. Create complaint missing required fields.
2. Create complaint with fake user ID (identity spoofing).
3. Create complaint with status != "Pending".
4. Update complaint as a non-admin.
5. Update complaint as an admin but setting an invalid status.
6. Read `complaints/{complaintId}` as a non-owner, non-admin.
7. Read `complaints/{complaintId}/private/info` as a non-owner, non-admin.
8. Create `admins/{uid}` document to escalate privileges (must be blocked).
9. Create complaint with overly large description string (resource exhaustion).
10. Create complaint with extra undocumented fields (shadow update).
11. Update private PII as an admin (allowed? Or maybe only admin can update status. Let's allow admin to update).
12. Read a list of complaints as a non-admin (query trust test).
