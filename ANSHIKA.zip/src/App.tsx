import React, { useState } from 'react';
import { db } from './firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { FileText, Search, ShieldCheck, CheckCircle2, AlertCircle } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('complaint'); // 'complaint' | 'status'
  const [formData, setFormData] = useState({ name: '', phone: '', address: '', description: '' });
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');
    setSuccessMsg('');
    
    try {
      if (db) {
        await addDoc(collection(db, 'complaints'), {
          ...formData,
          status: 'Pending',
          createdAt: serverTimestamp(),
        });
      }
      setSuccessMsg('आपकी शिकायत सफलतापूर्वक दर्ज कर ली गई है। (Complaint submitted successfully)');
      setFormData({ name: '', phone: '', address: '', description: '' });
    } catch (error) {
      console.error(error);
      setErrorMsg('कुछ तकनीकी समस्या आ गई है, कृपया बाद में प्रयास करें।');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-blue-700 text-white shadow-md">
        <div className="max-w-5xl mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <ShieldCheck className="w-10 h-10 text-yellow-300" />
            <div>
              <h1 className="text-2xl font-bold">झाबुआ जनसुनवाई</h1>
              <p className="text-blue-100 text-sm">Jhabua Collectorate Grievance Portal</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 py-8">
        
        {/* Tabs */}
        <div className="flex space-x-2 mb-8 bg-white p-2 rounded-xl shadow-sm w-fit mx-auto border border-slate-200">
          <button 
            onClick={() => setActiveTab('complaint')}
            className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-colors ${activeTab === 'complaint' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
          >
            <FileText className="w-5 h-5" />
            <span>शिकायत दर्ज करें (Register)</span>
          </button>
          <button 
            onClick={() => setActiveTab('status')}
            className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-colors ${activeTab === 'status' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
          >
            <Search className="w-5 h-5" />
            <span>स्थिति जांचें (Status)</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          
          {activeTab === 'complaint' && (
            <div className="p-8">
              <h2 className="text-xl font-semibold text-slate-800 mb-6 border-b pb-4">नई शिकायत दर्ज करें</h2>
              
              {successMsg && (
                <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start space-x-3 text-green-700">
                  <CheckCircle2 className="w-6 h-6 flex-shrink-0" />
                  <p className="font-medium">{successMsg}</p>
                </div>
              )}

              {errorMsg && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start space-x-3 text-red-700">
                  <AlertCircle className="w-6 h-6 flex-shrink-0" />
                  <p className="font-medium">{errorMsg}</p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">पूरा नाम (Full Name) *</label>
                    <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all" placeholder="अपना नाम लिखें" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">मोबाइल नंबर (Mobile) *</label>
                    <input required type="tel" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all" placeholder="10 अंकों का मोबाइल नंबर" />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">पता (Address) *</label>
                  <input required type="text" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all" placeholder="ग्राम/वार्ड, तहसील" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">शिकायत का विवरण (Complaint Details) *</label>
                  <textarea required rows={4} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all resize-none" placeholder="अपनी समस्या विस्तार से लिखें..."></textarea>
                </div>

                <div className="pt-4 border-t border-slate-100">
                  <button disabled={loading} type="submit" className="w-full md:w-auto px-8 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium rounded-xl transition-colors shadow-sm">
                    {loading ? 'दर्ज हो रहा है...' : 'शिकायत दर्ज करें (Submit)'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {activeTab === 'status' && (
            <div className="p-8 text-center py-16">
              <Search className="w-16 h-16 mx-auto text-slate-300 mb-4" />
              <h2 className="text-xl font-semibold text-slate-800 mb-2">शिकायत की स्थिति जांचें</h2>
              <p className="text-slate-500 mb-8 max-w-md mx-auto">अपना मोबाइल नंबर डालकर अपनी शिकायत की वर्तमान स्थिति के बारे में जानकारी प्राप्त करें।</p>
              
              <div className="max-w-md mx-auto flex space-x-2">
                <input type="text" className="flex-1 px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="मोबाइल नंबर दर्ज करें" />
                <button className="px-6 py-3 bg-slate-800 hover:bg-slate-900 text-white font-medium rounded-xl transition-colors">
                  खोजें
                </button>
              </div>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}
